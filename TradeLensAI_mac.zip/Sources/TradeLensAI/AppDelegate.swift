import AppKit
import SwiftUI

@MainActor
class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private var floatingPanel: FloatingPanel!
    private var appState: AppState!
    private var globalMonitor: Any?
    private var selectionOverlays: [ScreenSelectionOverlay] = []

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        appState = AppState()
        setupFloatingPanel()
        setupStatusBar()
        setupGlobalHotkey()
    }

    func applicationWillTerminate(_ notification: Notification) {
        if let monitor = globalMonitor { NSEvent.removeMonitor(monitor) }
    }

    // MARK: - Setup
    private func setupFloatingPanel() {
        appState.onRequestRegionSelection = { [weak self] in self?.startRegionSelection() }
        appState.onRequestRegionSelectionForAsk = { [weak self] in self?.startRegionSelectionForAsk() }
        let contentView = NSHostingView(rootView: FloatingPanelView(appState: appState))
        floatingPanel = FloatingPanel(contentView: contentView)
        floatingPanel.makeKeyAndOrderFront(nil)
    }

    private func setupStatusBar() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        guard let button = statusItem.button else { return }
        button.image = NSImage(systemSymbolName: "chart.xyaxis.line", accessibilityDescription: "ChristNote - TradeLens AI")
        statusItem.menu = buildMenu()
     }
 
     private func buildMenu() -> NSMenu {
         let menu = NSMenu()
         menu.addItem(withTitle: "About ChristNote", action: #selector(showAbout), keyEquivalent: "")
         menu.addItem(withTitle: "Show / Hide Panel", action: #selector(togglePanel), keyEquivalent: "")
         menu.addItem(.separator())
         menu.addItem(withTitle: "Select Region  ⌘⇧A", action: #selector(startRegionSelection), keyEquivalent: "")
         menu.addItem(withTitle: "Full Screen", action: #selector(captureFullScreen), keyEquivalent: "")
         menu.addItem(.separator())
         menu.addItem(withTitle: "Settings…", action: #selector(openSettings), keyEquivalent: ",")
         menu.addItem(.separator())
         menu.addItem(withTitle: "Quit ChristNote", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        return menu
    }

    // ⌘⇧A → region selection
    private func setupGlobalHotkey() {
        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { [weak self] event in
            let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
            if flags.contains([.command, .shift]) && event.charactersIgnoringModifiers?.lowercased() == "a" {
                DispatchQueue.main.async { self?.startRegionSelection() }
            }
        }
    }

    // MARK: - Actions
    @objc private func togglePanel() {
        if floatingPanel.isVisible { floatingPanel.orderOut(nil) }
        else { floatingPanel.makeKeyAndOrderFront(nil) }
    }

    @objc func startRegionSelection() {
        appState.beginRegionSelection()
        showOverlay { [weak self] cgRect, screen in
            Task { @MainActor in
                await self?.appState.captureRegionAndAnalyze(region: cgRect, screen: screen)
            }
        }
    }

    private func startRegionSelectionForAsk() {
        appState.beginRegionSelection()
        showOverlay { [weak self] cgRect, screen in
            Task { @MainActor in
                await self?.appState.askAboutScreenRegion(region: cgRect, screen: screen)
            }
        }
    }

    // Creates one overlay per connected screen so the user can select a region on any display.
    private func showOverlay(onSelect: @escaping (CGRect, NSScreen) -> Void) {
        floatingPanel.orderOut(nil)

        for screen in NSScreen.screens {
            let overlay = ScreenSelectionOverlay(screen: screen)
            selectionOverlays.append(overlay)

            overlay.onSelection = { [weak self] cgRect, selectedScreen in
                self?.dismissAllOverlays()
                self?.floatingPanel.makeKeyAndOrderFront(nil)
                onSelect(cgRect, selectedScreen)
            }
            overlay.onCancel = { [weak self] in
                self?.dismissAllOverlays()
                self?.floatingPanel.makeKeyAndOrderFront(nil)
                self?.appState.reset()
            }
            overlay.show()
        }
    }

    private func dismissAllOverlays() {
        let overlays = selectionOverlays
        selectionOverlays = []
        overlays.forEach { $0.close() }
        NSCursor.arrow.set()
    }

    @objc func showAbout() {
        NSApp.activate(ignoringOtherApps: true)
        NSApp.orderFrontStandardAboutPanel(nil)
    }

    @objc func openSettings() {
        SettingsWindowController.show(settings: appState.settings)
    }

    @objc func captureFullScreen() {
        floatingPanel.makeKeyAndOrderFront(nil)
        Task { @MainActor in
            await appState.captureAndAnalyze()
        }
    }
}
