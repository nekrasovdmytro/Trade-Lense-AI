import AppKit

extension NSImage {
    /// Encode as PNG base64 string
    func toBase64PNG() -> String? {
        pngData()?.base64EncodedString()
    }

    /// Encode as JPEG base64 string
    func toBase64JPEG(quality: Float = 0.8) -> String? {
        jpegData(compressionQuality: quality)?.base64EncodedString()
    }

    /// Raw PNG data
    func pngData() -> Data? {
        guard let tiff = tiffRepresentation,
              let rep  = NSBitmapImageRep(data: tiff) else { return nil }
        return rep.representation(using: .png, properties: [:])
    }

    /// Raw JPEG data
    func jpegData(compressionQuality: Float = 0.8) -> Data? {
        guard let tiff = tiffRepresentation,
              let rep  = NSBitmapImageRep(data: tiff) else { return nil }
        return rep.representation(using: .jpeg, properties: [.compressionFactor: compressionQuality])
    }

    /// Downscale so the longest edge ≤ maxDimension (keeps aspect ratio).
    /// Returns self unchanged if already smaller.
    func resized(maxDimension: CGFloat) -> NSImage {
        let longest = max(size.width, size.height)
        guard longest > maxDimension else { return self }
        let scale  = maxDimension / longest
        let newSize = NSSize(width: size.width * scale, height: size.height * scale)
        let result  = NSImage(size: newSize)
        result.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        draw(in: NSRect(origin: .zero, size: newSize),
             from: NSRect(origin: .zero, size: size),
             operation: .copy,
             fraction: 1.0)
        result.unlockFocus()
        return result
    }
}
