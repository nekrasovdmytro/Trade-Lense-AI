import SwiftUI
import Combine

enum AnalysisState {
    case idle
    case selectingRegion
    case capturing
    case preparing
    case analyzing(String) // Partial content for live updates
    case result(AnalysisResult)
    case error(String)
}

@MainActor
class AppState: ObservableObject {
    @Published var analysisState: AnalysisState = .idle
    @Published var history: [AnalysisResult] = []
    @Published var customPrompt: String = ""
    @Published var specificInstructions: String = ""

    // Audio / speech
    @Published var speechLiveText: String = ""
    @Published var isRecording: Bool = false
    @Published var lastScreenContext: String = ""

    let speechService = SpeechRecognitionService()

    private var currentTask: Task<Void, Never>? = nil
    private var cancellables: Set<AnyCancellable> = []

    let settings       = SettingsManager.shared
    let captureService = ScreenCaptureService()
    let storageService = StorageService()

    // Wired by AppDelegate — avoids unreliable NSApp.delegate cast from SwiftUI
    var onRequestRegionSelection: (() -> Void)?
    var onRequestRegionSelectionForAsk: (() -> Void)?

    init() {
        history = storageService.loadHistory()

        // Bind speech service state into AppState's published properties
        speechService.$liveText
            .receive(on: RunLoop.main)
            .assign(to: &$speechLiveText)

        speechService.$state
            .receive(on: RunLoop.main)
            .sink { [weak self] state in
                guard let self else { return }
                switch state {
                case .recording:
                    self.isRecording = true
                case .error(let errorMsg):
                    self.isRecording = false
                    self.analysisState = .error(errorMsg)
                case .idle:
                    self.isRecording = false
                }
            }
            .store(in: &cancellables)

        speechService.onFinalTranscript = { [weak self] text in
            guard let self else { return }
            // Append transcript to ask field
            let current = self.customPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
            self.customPrompt = current.isEmpty ? text : current + " " + text
        }
    }

    var isAnalyzing: Bool {
        switch analysisState {
        case .selectingRegion, .capturing, .preparing, .analyzing: true
        default: false
        }
    }

    // MARK: - Audio control

    func toggleRecording() {
        if isRecording {
            speechService.stop()
        } else {
            speechService.requestAuthorization { [weak self] granted in
                guard let self else { return }
                if granted {
                    self.speechService.start(languageID: self.settings.speechLanguageID)
                } else {
                    self.analysisState = .error("Microphone or speech recognition permission denied.\nGo to System Settings › Privacy & Security to grant access.")
                }
            }
        }
    }

    // MARK: - Chart analysis
    func captureAndAnalyze() async {
        analysisState = .capturing
        await run { try await self.captureService.captureScreen() }
    }

    func captureRegionAndAnalyze(region: CGRect, screen: NSScreen) async {
        analysisState = .capturing
        try? await Task.sleep(for: .milliseconds(150))
        await run { try await self.captureService.captureRegion(region, screen: screen) }
    }

    // MARK: - General "ask about screen"
    func askAboutScreen() async {
        if settings.selectedModel.isTextOnly {
            await runTextChat()
        } else {
            analysisState = .capturing
            await runGeneral { try await self.captureService.captureScreen() }
        }
    }

    func askAboutScreenRegion(region: CGRect, screen: NSScreen) async {
        if settings.selectedModel.isTextOnly {
            // Text models can't see images — use context chat instead
            await runTextChat()
        } else {
            analysisState = .capturing
            try? await Task.sleep(for: .milliseconds(150))
            await runGeneral { try await self.captureService.captureRegion(region, screen: screen) }
        }
    }

    func beginRegionSelection() { analysisState = .selectingRegion }
    func reset()                { analysisState = .idle }

    func stopAnalysis() {
        currentTask?.cancel()
        currentTask = nil
        analysisState = .idle
    }

    // MARK: - Private

    private func run(capture: @escaping () async throws -> NSImage) async {
        currentTask?.cancel()
        currentTask = Task {
            do {
                let image     = try await capture()
                if Task.isCancelled { return }

                analysisState = .preparing
                let router    = AIRouter(settings: settings)

                var result    = try await router.analyze(image: image, specificInstructions: specificInstructions) { partial in
                    if Task.isCancelled { return }
                    self.analysisState = .analyzing(partial)
                }

                if Task.isCancelled { return }

                result.screenshotData = image.jpegData(compressionQuality: 0.8)
                lastScreenContext = result.reasoning
                history.insert(result, at: 0)
                storageService.saveHistory(history)
                analysisState = .result(result)
            } catch {
                if !Task.isCancelled {
                    analysisState = .error(error.localizedDescription)
                }
            }
            currentTask = nil
        }
    }

    private func runGeneral(capture: @escaping () async throws -> NSImage) async {
        currentTask?.cancel()
        currentTask = Task {
            do {
                let image     = try await capture()
                if Task.isCancelled { return }

                analysisState = .preparing
                let router    = AIRouter(settings: settings)
                let audioCtx  = speechService.finalText

                var result    = try await router.analyzeGeneral(image: image, question: customPrompt, audioContext: audioCtx) { partial in
                    if Task.isCancelled { return }
                    self.analysisState = .analyzing(partial)
                }

                if Task.isCancelled { return }

                result.screenshotData = image.jpegData(compressionQuality: 0.8)
                lastScreenContext = result.reasoning
                history.insert(result, at: 0)
                storageService.saveHistory(history)
                analysisState = .result(result)
            } catch {
                if !Task.isCancelled {
                    analysisState = .error(error.localizedDescription)
                }
            }
            currentTask = nil
        }
    }

    private func runTextChat() async {
        currentTask?.cancel()
        currentTask = Task {
            do {
                analysisState = .preparing
                let router   = AIRouter(settings: settings)
                let audioCtx = speechService.finalText

                let result = try await router.chat(
                    question: customPrompt,
                    screenContext: lastScreenContext,
                    audioContext: audioCtx
                ) { partial in
                    if Task.isCancelled { return }
                    self.analysisState = .analyzing(partial)
                }

                if Task.isCancelled { return }

                history.insert(result, at: 0)
                storageService.saveHistory(history)
                analysisState = .result(result)
            } catch {
                if !Task.isCancelled {
                    analysisState = .error(error.localizedDescription)
                }
            }
            currentTask = nil
        }
    }
}
