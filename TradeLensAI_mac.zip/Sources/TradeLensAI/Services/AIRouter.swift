import AppKit

// Base system prompt — language suffix is appended at call time
// Keep this accessible to services that still reference it directly (test pings)
let tradingSystemPrompt = TradingMode.indicator.systemPromptBase

func buildSystemPrompt(mode: TradingMode, languageID: String) -> String {
    let base = mode.systemPromptBase
    guard languageID != "en" else { return base }
    let name = SupportedLanguage.name(for: languageID)
    return base + """

LANGUAGE: Write the "reasoning" text and every item in "key_signals" in \(name). \
Keep the "recommendation" value as one of the English keywords: BUY, SELL, SKIP, MORE_INFO.
"""
}

// MARK: - AIError (unified across all providers)

enum AIError: LocalizedError {
    case imageConversionFailed
    case missingAPIKey(provider: ProviderID)
    case apiError(provider: ProviderID, message: String)
    case invalidResponse
    case parseError
    case ollamaNotRunning(url: String)
    case networkError(Error)
    case missingCloudConsent

    var errorDescription: String? {
        switch self {
        case .imageConversionFailed:
            return "Could not encode the screenshot as PNG."
        case .missingAPIKey(let p):
            return "\(p.displayName) API key is not set. Open Settings (⚙) to add it."
        case .apiError(let p, let msg):
            return "\(p.displayName): \(msg)"
        case .invalidResponse:
            return "Server returned an unexpected response."
        case .parseError:
            return "Could not parse the AI response as JSON."
        case .ollamaNotRunning(let url):
            return "Ollama is not running at \(url).\nStart it with: ollama serve"
        case .networkError(let err):
            return "Network error: \(err.localizedDescription)"
        case .missingCloudConsent:
            return "GDPR Consent Required: You must consent to transmitting screen data to the cloud in Settings (⚙) before using cloud-based AI providers."
        }
    }
}

func buildGeneralPrompt(question: String, languageID: String) -> String {
    let q = question.trimmingCharacters(in: .whitespacesAndNewlines)
    let base = q.isEmpty
        ? "You are a helpful AI assistant. Describe what you see in this screenshot in detail."
        : "You are a helpful AI assistant analyzing a screenshot. Answer this question about what you see: \(q)\n\nRespond in plain text. Be concise and direct."
    guard languageID != "en" else { return base }
    let name = SupportedLanguage.name(for: languageID)
    return base + "\nRespond in \(name)."
}

// MARK: - Router

@MainActor
struct AIRouter {
    let settings: SettingsManager

    func analyze(image: NSImage, specificInstructions: String = "", onUpdate: ((String) -> Void)? = nil) async throws -> AnalysisResult {
        let mode = settings.selectedTradingMode
        var prompt = buildSystemPrompt(mode: mode, languageID: settings.responseLanguageID)
        
        let instructions = specificInstructions.trimmingCharacters(in: .whitespacesAndNewlines)
        var userMsg = "Analyze this trading chart. Reply only with the JSON format."
        if !instructions.isEmpty {
            userMsg += "\n\nSPECIFIC ANALYSIS FOCUS:\n\(instructions)\n\nPlease pay special attention to this focus in your analysis and reasoning!"
            prompt += "\n\nSPECIFIC ANALYSIS FOCUS: The user wants you to analyze the chart with this focus: \"\(instructions)\". Ensure your reasoning addresses this focus."
        }
        
        if settings.responseLanguageID != "en" {
            let name = SupportedLanguage.name(for: settings.responseLanguageID)
            userMsg += "\n\nIMPORTANT: Write the response reasoning and key signals in \(name)."
        }
        
        var result = try await callService(image: image, systemPrompt: prompt, userMessage: userMsg, onUpdate: onUpdate)
        result.mode = mode
        return result
    }

    func analyzeGeneral(image: NSImage, question: String, audioContext: String = "", onUpdate: ((String) -> Void)? = nil) async throws -> AnalysisResult {
        let prompt = buildGeneralPrompt(question: question, languageID: settings.responseLanguageID)
        var q = question.trimmingCharacters(in: .whitespacesAndNewlines)
        if !audioContext.isEmpty {
            q = q.isEmpty ? "Audio context: \(audioContext)" : "\(q)\n\n[Voice note]: \(audioContext)"
        }
        let userMsg = q.isEmpty ? "Describe this screenshot in detail." : q
        var result = try await callService(image: image, systemPrompt: prompt, userMessage: userMsg, onUpdate: onUpdate)
        result.isGeneralAnalysis = true
        if result.reasoning.isEmpty { result.reasoning = result.rawResponse }
        return result
    }

    // MARK: - Text-only chat (no image)

    func chat(question: String, screenContext: String, audioContext: String, onUpdate: ((String) -> Void)? = nil) async throws -> AnalysisResult {
        let provider = settings.selectedProviderID
        let model = settings.selectedModel

        if provider != .ollama && !settings.isCloudConsentGiven {
            throw AIError.missingCloudConsent
        }

        var systemPrompt = "You are a helpful AI assistant. Answer the user's question concisely and clearly."
        if !screenContext.isEmpty {
            systemPrompt += "\n\nSCREEN CONTEXT (from recent analysis):\n\(screenContext)"
        }
        if settings.responseLanguageID != "en" {
            let name = SupportedLanguage.name(for: settings.responseLanguageID)
            systemPrompt += "\n\nLANGUAGE: Respond in \(name)."
        }

        var userMsg = question.trimmingCharacters(in: .whitespacesAndNewlines)
        if userMsg.isEmpty { userMsg = "Please summarize the screen context." }
        if !audioContext.isEmpty {
            userMsg = "[Voice note]: \(audioContext)\n\n\(userMsg)"
        }

        let text: String

        switch provider {
        case .ollama:
            text = try await OllamaService(baseURL: settings.ollamaBaseURL)
                .chat(systemPrompt: systemPrompt, userMessage: userMsg, modelName: model.modelID, onUpdate: onUpdate)

        case .anthropic:
            guard let key = settings.apiKey(for: .anthropic), !key.isEmpty else {
                throw AIError.missingAPIKey(provider: .anthropic)
            }
            text = try await AnthropicService(apiKey: key)
                .chat(systemPrompt: systemPrompt, userMessage: userMsg, modelID: model.modelID)

        case .nvidia, .openai, .groq, .premium:
            guard let key = settings.apiKey(for: provider), !key.isEmpty else {
                throw AIError.missingAPIKey(provider: provider)
            }
            text = try await OpenAICompatibleService(
                baseURL: provider.defaultBaseURL, apiKey: key, provider: provider
            ).chat(systemPrompt: systemPrompt, userMessage: userMsg, modelID: model.modelID, onUpdate: onUpdate)
        }

        var result = AnalysisResult(recommendation: .skip, reasoning: text, rawResponse: text)
        result.isGeneralAnalysis = true
        return result
    }

    // MARK: - Private

    private func callService(image: NSImage, systemPrompt: String, userMessage: String, onUpdate: ((String) -> Void)? = nil) async throws -> AnalysisResult {
        let provider = settings.selectedProviderID
        let model    = settings.selectedModel

        if provider != .ollama && !settings.isCloudConsentGiven {
            throw AIError.missingCloudConsent
        }

        switch provider {
        case .ollama:
            return try await OllamaService(baseURL: settings.ollamaBaseURL)
                .analyze(image: image, modelName: model.modelID, systemPrompt: systemPrompt, userMessage: userMessage, onUpdate: onUpdate)

        case .anthropic:
            guard let key = settings.apiKey(for: .anthropic), !key.isEmpty else {
                throw AIError.missingAPIKey(provider: .anthropic)
            }
            return try await AnthropicService(apiKey: key)
                .analyze(image: image, modelID: model.modelID, systemPrompt: systemPrompt, userMessage: userMessage)

        case .nvidia, .openai, .groq, .premium:
            guard let key = settings.apiKey(for: provider), !key.isEmpty else {
                throw AIError.missingAPIKey(provider: provider)
            }
            return try await OpenAICompatibleService(
                baseURL: provider.defaultBaseURL,
                apiKey: key,
                provider: provider
            ).analyze(image: image, modelID: model.modelID, systemPrompt: systemPrompt, userMessage: userMessage)
        }
    }
}
