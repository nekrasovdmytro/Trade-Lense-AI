import SwiftUI

@MainActor
class SettingsManager: ObservableObject {
    static let shared = SettingsManager()

    @Published var selectedProviderID: ProviderID {
        didSet { ud.set(selectedProviderID.rawValue, forKey: Keys.provider) }
    }
    @Published var selectedModelID: String {
        didSet { ud.set(selectedModelID, forKey: Keys.model) }
    }
    @Published var ollamaBaseURL: String {
        didSet { ud.set(ollamaBaseURL, forKey: Keys.ollamaURL) }
    }
    @Published var appLanguageID: String {
        didSet { ud.set(appLanguageID, forKey: Keys.appLanguage) }
    }
    @Published var responseLanguageID: String {
        didSet { ud.set(responseLanguageID, forKey: Keys.language) }
    }
    @Published var speechLanguageID: String {
        didSet { ud.set(speechLanguageID, forKey: Keys.speechLanguage) }
    }
    @Published var isCloudConsentGiven: Bool {
        didSet { ud.set(isCloudConsentGiven, forKey: Keys.cloudConsent) }
    }
    @Published var selectedTradingModeID: String {
        didSet { ud.set(selectedTradingModeID, forKey: Keys.tradingMode) }
    }
    @Published var customOllamaModel: String {
        didSet {
            ud.set(customOllamaModel, forKey: Keys.customOllamaModel)
            ud.set(customOllamaModel, forKey: "customOllamaModel")
        }
    }
    @Published var customNvidiaModel: String {
        didSet {
            ud.set(customNvidiaModel, forKey: Keys.customNvidiaModel)
            ud.set(customNvidiaModel, forKey: "customNvidiaModel")
        }
    }
    // Bumped when any API key changes so Views that read keys re-evaluate
    @Published var keyVersion: Int = 0

    private let ud = UserDefaults.standard

    private enum Keys {
        static let provider  = "selectedProviderID"
        static let model     = "selectedModelID"
        static let ollamaURL = "ollamaBaseURL"
        static let appLanguage = "appLanguageID"
        static let language  = "responseLanguageID"
        static let speechLanguage = "speechLanguageID"
        static let cloudConsent = "isCloudConsentGiven"
        static let tradingMode = "selectedTradingModeID"
        static let customOllamaModel = "customOllamaModel"
        static let customNvidiaModel = "customNvidiaModel"
    }

    private init() {
        let raw = ud.string(forKey: Keys.provider) ?? ProviderID.ollama.rawValue
        selectedProviderID  = ProviderID(rawValue: raw) ?? .ollama
        selectedModelID     = ud.string(forKey: Keys.model)     ?? "qwen2.5vl:7b"
        ollamaBaseURL       = ud.string(forKey: Keys.ollamaURL) ?? "http://localhost:11434"
        appLanguageID       = ud.string(forKey: Keys.appLanguage) ?? SupportedLanguage.systemDefault.id
        responseLanguageID  = ud.string(forKey: Keys.language)  ?? SupportedLanguage.systemDefault.id
        speechLanguageID    = ud.string(forKey: Keys.speechLanguage) ?? SupportedLanguage.systemDefault.id
        isCloudConsentGiven = ud.bool(forKey: Keys.cloudConsent)
        selectedTradingModeID = ud.string(forKey: Keys.tradingMode) ?? TradingMode.indicator.rawValue
        customOllamaModel   = ud.string(forKey: Keys.customOllamaModel) ?? ""
        customNvidiaModel   = ud.string(forKey: Keys.customNvidiaModel) ?? ""
    }

    var selectedTradingMode: TradingMode {
        TradingMode(rawValue: selectedTradingModeID) ?? .indicator
    }

    var responseLanguage: SupportedLanguage {
        SupportedLanguage.all.first { $0.id == responseLanguageID } ?? SupportedLanguage.all[0]
    }

    // MARK: - Current selection
    var selectedModel: ModelOption {
        // Search vision models first, then text models
        if let m = selectedProviderID.visionModels.first(where: { $0.modelID == selectedModelID }) { return m }
        if let m = selectedProviderID.textModels.first(where: { $0.modelID == selectedModelID }) { return m }
        return selectedProviderID.visionModels[0]
    }

    func select(provider: ProviderID, model: ModelOption) {
        selectedProviderID = provider
        selectedModelID    = model.modelID
    }

    // MARK: - API keys (Keychain)
    func apiKey(for provider: ProviderID) -> String? {
        KeychainService.get("apikey.\(provider.rawValue)")
    }

    func setAPIKey(_ key: String, for provider: ProviderID) {
        if key.trimmingCharacters(in: .whitespaces).isEmpty {
            KeychainService.delete("apikey.\(provider.rawValue)")
        } else {
            KeychainService.set(key.trimmingCharacters(in: .whitespaces), forKey: "apikey.\(provider.rawValue)")
        }
        keyVersion += 1
    }

    func isConfigured(_ provider: ProviderID) -> Bool {
        guard provider.requiresAPIKey else { return true }
        return !(apiKey(for: provider) ?? "").isEmpty
    }
}
