import AppKit
import ScreenCaptureKit

struct ScreenCaptureService {
    func captureScreen() async throws -> NSImage {
        try await capture(region: nil, screen: NSScreen.main)
    }

    func captureRegion(_ cgRect: CGRect, screen: NSScreen) async throws -> NSImage {
        try await capture(region: cgRect, screen: screen)
    }

    private func capture(region: CGRect?, screen: NSScreen?) async throws -> NSImage {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)

        // Find the SCDisplay that matches the requested NSScreen by CGDirectDisplayID.
        let display: SCDisplay
        if let screen,
           let screenID = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? CGDirectDisplayID,
           let matched = content.displays.first(where: { $0.displayID == screenID }) {
            display = matched
        } else {
            guard let first = content.displays.first else { throw CaptureError.noDisplay }
            display = first
        }

        // Exclude every window that belongs to this app so the panel never appears in captures
        let ownBundleID = Bundle.main.bundleIdentifier ?? "com.christnote.tradelensai"
        let ownWindows  = content.windows.filter { $0.owningApplication?.bundleIdentifier == ownBundleID }

        let filter = SCContentFilter(display: display, excludingWindows: ownWindows)
        let config = SCStreamConfiguration()
        config.showsCursor = false

        // sourceRect is in display-local points (top-left origin); width/height are output pixels.
        let scale = screen?.backingScaleFactor ?? 2.0
        if let r = region {
            config.sourceRect = r
            config.width      = max(1, Int(r.width  * scale))
            config.height     = max(1, Int(r.height * scale))
        } else {
            config.width  = Int(Double(display.width)  * scale)
            config.height = Int(Double(display.height) * scale)
        }

        let cgImage = try await SCScreenshotManager.captureImage(
            contentFilter: filter,
            configuration: config
        )

        let size: NSSize
        if let r = region {
            size = NSSize(width: r.width, height: r.height)
        } else {
            size = NSSize(width: display.width, height: display.height)
        }

        return NSImage(cgImage: cgImage, size: size)
    }
}

enum CaptureError: LocalizedError {
    case noDisplay
    var errorDescription: String? { "No display found." }
}
