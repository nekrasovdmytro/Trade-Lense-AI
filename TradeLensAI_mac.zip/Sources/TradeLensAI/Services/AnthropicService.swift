import AppKit

struct AnthropicService {
    let apiKey: String
    private let endpoint = "https://api.anthropic.com/v1/messages"

    func analyze(image: NSImage, modelID: String, systemPrompt: String = tradingSystemPrompt, userMessage: String = "Analyze this trading chart. Reply only with the JSON format.") async throws -> AnalysisResult {
        guard let base64 = image.resized(maxDimension: 1024).toBase64PNG() else {
            throw AIError.imageConversionFailed
        }

        let body: [String: Any] = [
            "model":      modelID,
            "max_tokens": 1024,
            "system":     systemPrompt,
            "messages": [[
                "role": "user",
                "content": [
                    ["type": "image",
                     "source": ["type": "base64",
                                "media_type": "image/png",
                                "data": base64]],
                    ["type": "text",
                     "text": userMessage]
                ]
            ]]
        ]

        var req = URLRequest(url: URL(string: endpoint)!)
        req.httpMethod = "POST"
        req.setValue("application/json",  forHTTPHeaderField: "Content-Type")
        req.setValue(apiKey,              forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01",        forHTTPHeaderField: "anthropic-version")
        req.timeoutInterval = 120
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)

        guard let http = response as? HTTPURLResponse else {
            throw AIError.invalidResponse
        }
        guard http.statusCode == 200 else {
            throw AIError.apiError(provider: .anthropic, message: httpError(data: data, status: http.statusCode))
        }

        guard let json    = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let content = json["content"] as? [[String: Any]],
              let first   = content.first,
              let text    = first["text"] as? String else {
            throw AIError.parseError
        }

        return parseContent(text)
    }

    // MARK: - Text-only chat (no image)

    func chat(systemPrompt: String, userMessage: String, modelID: String) async throws -> String {
        var body: [String: Any] = [
            "model": modelID,
            "max_tokens": 2048,
            "messages": [["role": "user", "content": userMessage]]
        ]
        if !systemPrompt.isEmpty { body["system"] = systemPrompt }

        var req = URLRequest(url: URL(string: endpoint)!)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(apiKey,             forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01",       forHTTPHeaderField: "anthropic-version")
        req.timeoutInterval = 120
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw AIError.apiError(provider: .anthropic, message: httpError(data: data, status: (response as? HTTPURLResponse)?.statusCode ?? -1))
        }
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let content = json["content"] as? [[String: Any]],
              let text = content.first?["text"] as? String else {
            throw AIError.parseError
        }
        return text
    }

    // MARK: - Connection test
    func testConnection(modelID: String) async -> (ok: Bool, message: String) {
        let body: [String: Any] = [
            "model": modelID, "max_tokens": 8,
            "messages": [["role": "user", "content": "Say OK"]]
        ]
        var req = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(apiKey,             forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01",       forHTTPHeaderField: "anthropic-version")
        req.timeoutInterval = 15
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { return (false, "No HTTP response") }
            if http.statusCode == 200 { return (true, "Connected (\(http.statusCode))") }
            return (false, "HTTP \(http.statusCode): \(httpError(data: data, status: http.statusCode))")
        } catch { return (false, error.localizedDescription) }
    }

    private func httpError(data: Data, status: Int) -> String {
        if let json  = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let error = json["error"] as? [String: Any],
           let msg   = error["message"] as? String { return msg }
        return "HTTP \(status)"
    }

    private func parseContent(_ content: String) -> AnalysisResult {
        var parsedRec: String? = nil
        var parsedReasoning: String? = nil
        var parsedConfidence: Double? = nil
        var parsedSignals: [String]? = nil
        
        if let jsonStr = extractJSON(from: content),
           let data = jsonStr.data(using: .utf8) {
            if let parsed = try? JSONDecoder().decode(ParsedAnalysis.self, from: data) {
                parsedRec = parsed.recommendation
                parsedReasoning = parsed.reasoning
                parsedConfidence = parsed.confidence
                parsedSignals = parsed.key_signals
            } else {
                // Regex fallback for malformed JSON
                parsedRec = regexExtract(pattern: "\"recommendation\"\\s*:\\s*\"([^\"]+)\"", from: jsonStr)
                parsedReasoning = regexExtract(pattern: "\"reasoning\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"", from: jsonStr)?
                    .replacingOccurrences(of: "\\n", with: "\n")
                    .replacingOccurrences(of: "\\\"", with: "\"")
                
                if let confStr = regexExtract(pattern: "\"confidence\"\\s*:\\s*([0-9.]+)", from: jsonStr) {
                    parsedConfidence = Double(confStr)
                }
                
                // Key signals extraction
                if let signalsBlock = regexExtract(pattern: "\"key_signals\"\\s*:\\s*\\[([^\\]]*)\\]", from: jsonStr) {
                    let pattern = "\"([^\"]+)\""
                    let regex = try? NSRegularExpression(pattern: pattern, options: [])
                    let nsRange = NSRange(signalsBlock.startIndex..<signalsBlock.endIndex, in: signalsBlock)
                    if let matches = regex?.matches(in: signalsBlock, options: [], range: nsRange) {
                        var signals: [String] = []
                        for match in matches {
                            if let range = Range(match.range(at: 1), in: signalsBlock) {
                                signals.append(String(signalsBlock[range]))
                            }
                        }
                        parsedSignals = signals
                    }
                }
            }
        }
        
        if let reasoning = parsedReasoning, !reasoning.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            var recRaw = parsedRec?.uppercased() ?? "SKIP"
            if recRaw == "BULLISH" { recRaw = "BUY" }
            if recRaw == "BEARISH" { recRaw = "SELL" }
            if recRaw == "NEUTRAL" { recRaw = "SKIP" }
            let rec = Recommendation(rawValue: recRaw) ?? .skip
            return AnalysisResult(
                recommendation: rec,
                reasoning:      reasoning,
                confidence:     parsedConfidence,
                keySignals:     parsedSignals,
                rawResponse:    content
            )
        }
        
        return AnalysisResult(recommendation: .skip, reasoning: content, rawResponse: content)
    }

    private func regexExtract(pattern: String, from text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let nsRange = NSRange(text.startIndex..<text.endIndex, in: text)
        if let match = regex.firstMatch(in: text, options: [], range: nsRange),
           let range = Range(match.range(at: 1), in: text) {
            return String(text[range])
        }
        return nil
    }

    private func extractJSON(from text: String) -> String? {
        guard let s = text.range(of: "{"),
              let e = text.range(of: "}", options: .backwards) else { return nil }
        return String(text[s.lowerBound...e.upperBound])
    }
}

private struct ParsedAnalysis: Decodable {
    let recommendation: String?
    let confidence:     Double?
    let reasoning:      String?
    let key_signals:    [String]?

    enum CodingKeys: String, CodingKey {
        case recommendation
        case confidence
        case reasoning
        case key_signals
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.recommendation = try? container.decode(String.self, forKey: .recommendation)
        self.reasoning = try? container.decode(String.self, forKey: .reasoning)
        self.key_signals = try? container.decode([String].self, forKey: .key_signals)
        
        // Robust confidence decoding
        if let doubleVal = try? container.decode(Double.self, forKey: .confidence) {
            self.confidence = doubleVal
        } else if let stringVal = try? container.decode(String.self, forKey: .confidence),
                  let doubleVal = Double(stringVal) {
            self.confidence = doubleVal
        } else if let intVal = try? container.decode(Int.self, forKey: .confidence) {
            self.confidence = Double(intVal)
        } else {
            self.confidence = nil
        }
    }
}
