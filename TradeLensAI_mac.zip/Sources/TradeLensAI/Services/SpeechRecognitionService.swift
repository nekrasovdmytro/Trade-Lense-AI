import Foundation
import Speech
import AVFoundation

@MainActor
final class SpeechRecognitionService: ObservableObject {

    enum RecState: Equatable {
        case idle
        case recording
        case error(String)
    }

    @Published var state: RecState = .idle
    @Published var liveText: String = ""   // partial real-time result
    @Published var finalText: String = ""  // committed on stop

    var onFinalTranscript: ((String) -> Void)?

    private var recognizer: SFSpeechRecognizer?
    private var engine: AVAudioEngine?
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private var tapInstalled = false

    init() {}

    // MARK: - Authorization

    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { speechStatus in
            guard speechStatus == .authorized else {
                DispatchQueue.main.async { completion(false) }
                return
            }
            
            AVCaptureDevice.requestAccess(for: .audio) { micGranted in
                DispatchQueue.main.async { completion(micGranted) }
            }
        }
    }

    var isAvailable: Bool {
        SFSpeechRecognizer.authorizationStatus() == .authorized
    }

    // MARK: - Control

    func start(languageID: String) {
        let locale = speechLocale(for: languageID)
        let rec = SFSpeechRecognizer(locale: locale)
               ?? SFSpeechRecognizer(locale: Locale(identifier: "en-US"))

        guard let rec, rec.isAvailable else {
            state = .error("Speech recognition not available. Check System Settings › Privacy › Speech Recognition.")
            return
        }
        recognizer = rec
        beginSession()
    }

    func stop() {
        endSession(publish: true)
    }

    var isRecording: Bool {
        if case .recording = state { return true }
        return false
    }

    // MARK: - Private

    private func beginSession() {
        endSession(publish: false)

        let eng = AVAudioEngine()
        engine = eng

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        request = req

        let inputNode = eng.inputNode
        let fmt = inputNode.outputFormat(forBus: 0)

        guard fmt.sampleRate > 0 else {
            state = .error("Audio input device not found or has an invalid configuration.")
            teardown()
            return
        }

        tapInstalled = true
        inputNode.installTap(onBus: 0, bufferSize: 4096, format: fmt) { [weak self] buffer, _ in
            self?.request?.append(buffer)
            Task { @MainActor [weak self] in self?.armSilenceTimer() }
        }

        do {
            eng.prepare()
            try eng.start()
        } catch {
            state = .error("Audio engine: \(error.localizedDescription)")
            teardown()
            return
        }

        state = .recording
        liveText = ""

        task = recognizer?.recognitionTask(with: req) { [weak self] result, err in
            Task { @MainActor [weak self] in
                guard let self else { return }
                if let r = result {
                    self.liveText = r.bestTranscription.formattedString
                    if r.isFinal { self.endSession(publish: true) }
                }
                if err != nil, !self.liveText.isEmpty {
                    self.endSession(publish: true)
                }
            }
        }
    }

    private func endSession(publish: Bool) {
        silenceTimer?.invalidate()
        silenceTimer = nil

        request?.endAudio()

        if let eng = engine {
            if tapInstalled {
                eng.inputNode.removeTap(onBus: 0)
                tapInstalled = false
            }
            if eng.isRunning { eng.stop() }
        }
        engine = nil
        task?.cancel()
        task = nil
        request = nil

        if publish && !liveText.isEmpty {
            finalText = liveText
            onFinalTranscript?(liveText)
        }

        if case .recording = state { state = .idle }
    }

    private func teardown() {
        if let eng = engine {
            if tapInstalled { eng.inputNode.removeTap(onBus: 0); tapInstalled = false }
            if eng.isRunning { eng.stop() }
        }
        engine = nil; task?.cancel(); task = nil; request = nil
    }

    private func armSilenceTimer() {
        guard isRecording else { return }
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.isRecording else { return }
                self.endSession(publish: true)
            }
        }
    }

    // MARK: - Locale mapping

    private func speechLocale(for id: String) -> Locale {
        let map: [String: String] = [
            "en": "en-US", "uk": "uk-UA", "de": "de-DE", "fr": "fr-FR",
            "es": "es-ES", "it": "it-IT", "pt": "pt-BR", "ru": "ru-RU",
            "pl": "pl-PL", "nl": "nl-NL", "zh": "zh-CN", "ja": "ja-JP",
            "ko": "ko-KR", "ar": "ar-SA", "hi": "hi-IN", "tr": "tr-TR",
            "vi": "vi-VN", "th": "th-TH", "id": "id-ID"
        ]
        return Locale(identifier: map[id] ?? "en-US")
    }
}
