import Foundation

class LicensingService {
    static let shared = LicensingService()
    
    private let defaults = UserDefaults.standard
    private let firstLaunchKey = "licensing_first_launch_date"
    private let activationCodeKey = "licensing_activation_code"
    
    // 50 Euro one-time payment unlock code (example logic)
    // In a real app, this would be verified against a server
    private let validActivationCodePrefix = "AS-PRO-" 
    
    init() {
        if defaults.object(forKey: firstLaunchKey) == nil {
            defaults.set(Date(), forKey: firstLaunchKey)
        }
    }
    
    var firstLaunchDate: Date {
        defaults.object(forKey: firstLaunchKey) as? Date ?? Date()
    }
    
    // All users are PRO — no trial restrictions
    var isActivated: Bool { true }
    var trialDaysRemaining: Int { 90 }
    var isTrialExpired: Bool { false }
    
    func activate(with code: String) -> Bool {
        if code.hasPrefix(validActivationCodePrefix) && code.count > 10 {
            defaults.set(code, forKey: activationCodeKey)
            return true
        }
        return false
    }
    
    func deactivate() {
        defaults.removeObject(forKey: activationCodeKey)
    }
}
