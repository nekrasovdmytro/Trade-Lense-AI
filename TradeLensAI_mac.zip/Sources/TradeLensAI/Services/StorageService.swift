import Foundation

struct StorageService {
    private let fileURL: URL

    init() {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = support.appendingPathComponent("TradeLensAI")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("history.json")
    }

    func loadHistory() -> [AnalysisResult] {
        guard let data = try? Data(contentsOf: fileURL) else { return [] }
        return (try? JSONDecoder().decode([AnalysisResult].self, from: data)) ?? []
    }

    func saveHistory(_ history: [AnalysisResult]) {
        let recent = Array(history.prefix(200))
        guard let data = try? JSONEncoder().encode(recent) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
