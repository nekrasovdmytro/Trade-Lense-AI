import AppKit

struct OllamaService {
    let baseURL: String

    private var chatURL: URL? { URL(string: "\(baseURL)/api/chat") }

    func analyze(image: NSImage, modelName: String, systemPrompt: String = tradingSystemPrompt, userMessage: String = "Analyze this trading chart. Reply only with the JSON format.", onUpdate: ((String) -> Void)? = nil) async throws -> AnalysisResult {
        guard let url = chatURL else {
            throw AIError.apiError(provider: .ollama, message: "Invalid Ollama URL: \(baseURL)")
        }

        // Local models are slow/unstable with large images — cap strictly and use JPEG
        guard let base64 = image.resized(maxDimension: 768).toBase64JPEG(quality: 0.7) else {
            throw AIError.imageConversionFailed
        }

        let combinedPrompt = "\(systemPrompt)\n\n\(userMessage)"
        let body: [String: Any] = [
            "model":  modelName,
            "stream": onUpdate != nil,
            "messages": [
                ["role": "user",   "content": combinedPrompt, "images": [base64]]
            ]
        ]

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 300
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        if let onUpdate = onUpdate {
            return try await performStreamingRequest(req, onUpdate: onUpdate)
        } else {
            return try await performStandardRequest(req)
        }
    }

    private func performStandardRequest(_ req: URLRequest) async throws -> AnalysisResult {
        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: req)
        } catch {
            throw AIError.ollamaNotRunning(url: baseURL)
        }

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw AIError.apiError(provider: .ollama, message: "HTTP \(code)")
        }

        guard let json    = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let message = json["message"] as? [String: Any],
              let content = message["content"] as? String else {
            throw AIError.parseError
        }

        return parseContent(content)
    }

    private func performStreamingRequest(_ req: URLRequest, onUpdate: (String) -> Void) async throws -> AnalysisResult {
        let (bytes, response): (URLSession.AsyncBytes, URLResponse)
        do {
            (bytes, response) = try await URLSession.shared.bytes(for: req)
        } catch {
            throw AIError.ollamaNotRunning(url: baseURL)
        }

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw AIError.apiError(provider: .ollama, message: "HTTP \(code)")
        }

        var fullContent = ""
        do {
            for try await line in bytes.lines {
                guard let data = line.data(using: .utf8), !data.isEmpty else { continue }
                
                // Ollama sends one JSON object per line. If a line is invalid, we skip it rather than crashing.
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let message = json["message"] as? [String: Any],
                   let content = message["content"] as? String {
                    
                    fullContent += content
                    onUpdate(fullContent)
                    
                    if let done = json["done"] as? Bool, done { break }
                }
            }
        } catch {
            // If the stream breaks prematurely, we still return what we have
            if fullContent.isEmpty { throw AIError.networkError(error) }
        }

        return parseContent(fullContent)
    }

    // MARK: - Text-only chat (no image)

    func chat(systemPrompt: String, userMessage: String, modelName: String, onUpdate: ((String) -> Void)? = nil) async throws -> String {
        guard let url = chatURL else {
            throw AIError.apiError(provider: .ollama, message: "Invalid Ollama URL: \(baseURL)")
        }

        var messages: [[String: Any]] = []
        if !systemPrompt.isEmpty {
            messages.append(["role": "system", "content": systemPrompt])
        }
        messages.append(["role": "user", "content": userMessage])

        let body: [String: Any] = [
            "model": modelName,
            "stream": onUpdate != nil,
            "messages": messages
        ]

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 300
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        if let onUpdate = onUpdate {
            return try await streamChat(req, onUpdate: onUpdate)
        } else {
            return try await standardChat(req)
        }
    }

    private func standardChat(_ req: URLRequest) async throws -> String {
        let (data, response): (Data, URLResponse)
        do { (data, response) = try await URLSession.shared.data(for: req) }
        catch { throw AIError.ollamaNotRunning(url: baseURL) }

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw AIError.apiError(provider: .ollama, message: "HTTP \((response as? HTTPURLResponse)?.statusCode ?? -1)")
        }
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let msg = json["message"] as? [String: Any],
              let content = msg["content"] as? String else {
            throw AIError.parseError
        }
        return content
    }

    private func streamChat(_ req: URLRequest, onUpdate: (String) -> Void) async throws -> String {
        let (bytes, response): (URLSession.AsyncBytes, URLResponse)
        do { (bytes, response) = try await URLSession.shared.bytes(for: req) }
        catch { throw AIError.ollamaNotRunning(url: baseURL) }

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw AIError.apiError(provider: .ollama, message: "HTTP \((response as? HTTPURLResponse)?.statusCode ?? -1)")
        }

        var fullContent = ""
        for try await line in bytes.lines {
            guard let data = line.data(using: .utf8), !data.isEmpty else { continue }
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let msg = json["message"] as? [String: Any],
               let content = msg["content"] as? String {
                fullContent += content
                onUpdate(fullContent)
                if let done = json["done"] as? Bool, done { break }
            }
        }
        return fullContent
    }

    // MARK: - Connection test
    func testConnection() async -> (ok: Bool, message: String) {
        guard let url = URL(string: "\(baseURL)/api/tags") else {
            return (false, "Invalid URL")
        }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse else { return (false, "No HTTP response") }
            if http.statusCode == 200 {
                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let models = json["models"] as? [[String: Any]] {
                    return (true, "Connected — \(models.count) model(s) installed")
                }
                return (true, "Connected")
            }
            return (false, "HTTP \(http.statusCode)")
        } catch {
            return (false, "Cannot reach Ollama at \(baseURL). Is it running?")
        }
    }

    // MARK: - Parsing
    private func parseContent(_ content: String) -> AnalysisResult {
        var parsedRec: String? = nil
        var parsedReasoning: String? = nil
        var parsedConfidence: Double? = nil
        var parsedSignals: [String]? = nil
        
        if let jsonStr = extractJSON(from: content),
           let data = jsonStr.data(using: .utf8) {
            if let parsed = try? JSONDecoder().decode(ParsedAnalysis.self, from: data) {
                parsedRec = parsed.recommendation
                parsedReasoning = parsed.reasoning
                parsedConfidence = parsed.confidence
                parsedSignals = parsed.key_signals
            } else {
                // Regex fallback for malformed JSON
                parsedRec = regexExtract(pattern: "\"recommendation\"\\s*:\\s*\"([^\"]+)\"", from: jsonStr)
                parsedReasoning = regexExtract(pattern: "\"reasoning\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"", from: jsonStr)?
                    .replacingOccurrences(of: "\\n", with: "\n")
                    .replacingOccurrences(of: "\\\"", with: "\"")
                
                if let confStr = regexExtract(pattern: "\"confidence\"\\s*:\\s*([0-9.]+)", from: jsonStr) {
                    parsedConfidence = Double(confStr)
                }
                
                // Key signals extraction
                if let signalsBlock = regexExtract(pattern: "\"key_signals\"\\s*:\\s*\\[([^\\]]*)\\]", from: jsonStr) {
                    let pattern = "\"([^\"]+)\""
                    let regex = try? NSRegularExpression(pattern: pattern, options: [])
                    let nsRange = NSRange(signalsBlock.startIndex..<signalsBlock.endIndex, in: signalsBlock)
                    if let matches = regex?.matches(in: signalsBlock, options: [], range: nsRange) {
                        var signals: [String] = []
                        for match in matches {
                            if let range = Range(match.range(at: 1), in: signalsBlock) {
                                signals.append(String(signalsBlock[range]))
                            }
                        }
                        parsedSignals = signals
                    }
                }
            }
        }
        
        if let reasoning = parsedReasoning, !reasoning.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            var recRaw = parsedRec?.uppercased() ?? "SKIP"
            if recRaw == "BULLISH" { recRaw = "BUY" }
            if recRaw == "BEARISH" { recRaw = "SELL" }
            if recRaw == "NEUTRAL" { recRaw = "SKIP" }
            let rec = Recommendation(rawValue: recRaw) ?? .skip
            return AnalysisResult(
                recommendation: rec,
                reasoning:      reasoning,
                confidence:     parsedConfidence,
                keySignals:     parsedSignals,
                rawResponse:    content
            )
        }
        
        // Fallback for non-JSON or partial/broken JSON
        let rec: Recommendation
        let u = content.uppercased()
        if u.contains("BUY")  { rec = .buy  }
        else if u.contains("SELL") { rec = .sell }
        else if u.contains("MORE") { rec = .moreInfo }
        else { rec = .skip }
        return AnalysisResult(recommendation: rec, reasoning: content, rawResponse: content)
    }

    private func regexExtract(pattern: String, from text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let nsRange = NSRange(text.startIndex..<text.endIndex, in: text)
        if let match = regex.firstMatch(in: text, options: [], range: nsRange),
           let range = Range(match.range(at: 1), in: text) {
            return String(text[range])
        }
        return nil
    }

    private func extractJSON(from text: String) -> String? {
        guard let start = text.firstIndex(of: "{"),
              let end = text.lastIndex(of: "}") ,
              start < end else { return nil }
        
        return String(text[start...end])
    }
}

private struct ParsedAnalysis: Decodable {
    let recommendation: String?
    let confidence:     Double?
    let reasoning:      String?
    let key_signals:    [String]?

    enum CodingKeys: String, CodingKey {
        case recommendation
        case confidence
        case reasoning
        case key_signals
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.recommendation = try? container.decode(String.self, forKey: .recommendation)
        self.reasoning = try? container.decode(String.self, forKey: .reasoning)
        self.key_signals = try? container.decode([String].self, forKey: .key_signals)
        
        // Robust confidence decoding
        if let doubleVal = try? container.decode(Double.self, forKey: .confidence) {
            self.confidence = doubleVal
        } else if let stringVal = try? container.decode(String.self, forKey: .confidence),
                  let doubleVal = Double(stringVal) {
            self.confidence = doubleVal
        } else if let intVal = try? container.decode(Int.self, forKey: .confidence) {
            self.confidence = Double(intVal)
        } else {
            self.confidence = nil
        }
    }
}
