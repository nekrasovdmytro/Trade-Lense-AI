import AppKit

// Handles: NVIDIA NIM, OpenAI, Groq — all speak the OpenAI chat/completions format
struct OpenAICompatibleService {
    let baseURL: String
    let apiKey: String
    let provider: ProviderID

    func analyze(image: NSImage, modelID: String, systemPrompt: String = tradingSystemPrompt, userMessage: String = "Analyze this trading chart. Reply only with the JSON format.") async throws -> AnalysisResult {
        guard let base64 = image.resized(maxDimension: 1280).toBase64PNG() else {
            throw AIError.imageConversionFailed
        }

        let combinedPrompt = "\(systemPrompt)\n\n\(userMessage)"
        let body: [String: Any] = [
            "model": modelID,
            "stream": false,
            "max_tokens": 1024,
            "messages": [
                ["role": "user", "content": [
                    ["type": "text",
                     "text": combinedPrompt],
                    ["type": "image_url",
                     "image_url": ["url": "data:image/png;base64,\(base64)", "detail": "high"]]
                ]]
            ]
        ]

        let url = URL(string: "\(baseURL)/chat/completions")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json",    forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(apiKey)",    forHTTPHeaderField: "Authorization")
        req.timeoutInterval = 120
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)

        guard let http = response as? HTTPURLResponse else {
            throw AIError.invalidResponse
        }
        guard http.statusCode == 200 else {
            throw AIError.apiError(provider: provider, message: httpError(data: data, status: http.statusCode))
        }

        guard let json     = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices  = json["choices"] as? [[String: Any]],
              let first    = choices.first,
              let message  = first["message"] as? [String: Any],
              let content  = message["content"] as? String else {
            throw AIError.parseError
        }

        return parseContent(content)
    }

    // MARK: - Text-only chat (no image)

    func chat(systemPrompt: String, userMessage: String, modelID: String, onUpdate: ((String) -> Void)? = nil) async throws -> String {
        var messages: [[String: Any]] = []
        if !systemPrompt.isEmpty {
            messages.append(["role": "system", "content": systemPrompt])
        }
        messages.append(["role": "user", "content": userMessage])

        let body: [String: Any] = [
            "model": modelID,
            "stream": onUpdate != nil,
            "max_tokens": 2048,
            "messages": messages
        ]

        let url = URL(string: "\(baseURL)/chat/completions")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(apiKey)",  forHTTPHeaderField: "Authorization")
        req.timeoutInterval = 120
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        if let onUpdate = onUpdate {
            return try await streamTextResponse(req, onUpdate: onUpdate)
        } else {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                let code = (response as? HTTPURLResponse)?.statusCode ?? -1
                throw AIError.apiError(provider: provider, message: httpError(data: data, status: code))
            }
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let choices = json["choices"] as? [[String: Any]],
                  let message = choices.first?["message"] as? [String: Any],
                  let content = message["content"] as? String else {
                throw AIError.parseError
            }
            return content
        }
    }

    private func streamTextResponse(_ req: URLRequest, onUpdate: (String) -> Void) async throws -> String {
        let (bytes, response) = try await URLSession.shared.bytes(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw AIError.apiError(provider: provider, message: "HTTP \((response as? HTTPURLResponse)?.statusCode ?? -1)")
        }
        var full = ""
        for try await line in bytes.lines {
            let stripped = line.trimmingCharacters(in: .whitespaces)
            guard stripped.hasPrefix("data: ") else { continue }
            let dataStr = String(stripped.dropFirst(6))
            guard dataStr != "[DONE]" else { break }
            if let data = dataStr.data(using: .utf8),
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let delta = (json["choices"] as? [[String: Any]])?.first?["delta"] as? [String: Any],
               let content = delta["content"] as? String {
                full += content
                onUpdate(full)
            }
        }
        return full
    }

    // MARK: - Connection test (text-only, no image — fast)
    func testConnection(modelID: String) async -> (ok: Bool, message: String) {
        let body: [String: Any] = [
            "model": modelID,
            "stream": false,
            "max_tokens": 8,
            "messages": [["role": "user", "content": "Say OK"]]
        ]
        var req = URLRequest(url: URL(string: "\(baseURL)/chat/completions")!)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(apiKey)",  forHTTPHeaderField: "Authorization")
        req.timeoutInterval = 15
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse else { return (false, "No HTTP response") }
            if http.statusCode == 200 { return (true, "Connected (\(http.statusCode))") }
            return (false, "HTTP \(http.statusCode): \(httpError(data: data, status: http.statusCode))")
        } catch {
            return (false, error.localizedDescription)
        }
    }

    // MARK: - Helpers
    private func httpError(data: Data, status: Int) -> String {
        if let json  = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let error = json["error"] as? [String: Any],
           let msg   = error["message"] as? String { return msg }
        return "HTTP \(status)"
    }

    private func parseContent(_ content: String) -> AnalysisResult {
        var parsedRec: String? = nil
        var parsedReasoning: String? = nil
        var parsedConfidence: Double? = nil
        var parsedSignals: [String]? = nil
        
        if let jsonStr = extractJSON(from: content),
           let data = jsonStr.data(using: .utf8) {
            if let parsed = try? JSONDecoder().decode(ParsedAnalysis.self, from: data) {
                parsedRec = parsed.recommendation
                parsedReasoning = parsed.reasoning
                parsedConfidence = parsed.confidence
                parsedSignals = parsed.key_signals
            } else {
                // Regex fallback for malformed JSON
                parsedRec = regexExtract(pattern: "\"recommendation\"\\s*:\\s*\"([^\"]+)\"", from: jsonStr)
                parsedReasoning = regexExtract(pattern: "\"reasoning\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"", from: jsonStr)?
                    .replacingOccurrences(of: "\\n", with: "\n")
                    .replacingOccurrences(of: "\\\"", with: "\"")
                
                if let confStr = regexExtract(pattern: "\"confidence\"\\s*:\\s*([0-9.]+)", from: jsonStr) {
                    parsedConfidence = Double(confStr)
                }
                
                // Key signals extraction
                if let signalsBlock = regexExtract(pattern: "\"key_signals\"\\s*:\\s*\\[([^\\]]*)\\]", from: jsonStr) {
                    let pattern = "\"([^\"]+)\""
                    let regex = try? NSRegularExpression(pattern: pattern, options: [])
                    let nsRange = NSRange(signalsBlock.startIndex..<signalsBlock.endIndex, in: signalsBlock)
                    if let matches = regex?.matches(in: signalsBlock, options: [], range: nsRange) {
                        var signals: [String] = []
                        for match in matches {
                            if let range = Range(match.range(at: 1), in: signalsBlock) {
                                signals.append(String(signalsBlock[range]))
                            }
                        }
                        parsedSignals = signals
                    }
                }
            }
        }
        
        if let reasoning = parsedReasoning, !reasoning.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            var recRaw = parsedRec?.uppercased() ?? "SKIP"
            if recRaw == "BULLISH" { recRaw = "BUY" }
            if recRaw == "BEARISH" { recRaw = "SELL" }
            if recRaw == "NEUTRAL" { recRaw = "SKIP" }
            let rec = Recommendation(rawValue: recRaw) ?? .skip
            return AnalysisResult(
                recommendation: rec,
                reasoning:      reasoning,
                confidence:     parsedConfidence,
                keySignals:     parsedSignals,
                rawResponse:    content
            )
        }
        
        return AnalysisResult(
            recommendation: detectRec(in: content),
            reasoning:      content,
            rawResponse:    content
        )
    }

    private func regexExtract(pattern: String, from text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let nsRange = NSRange(text.startIndex..<text.endIndex, in: text)
        if let match = regex.firstMatch(in: text, options: [], range: nsRange),
           let range = Range(match.range(at: 1), in: text) {
            return String(text[range])
        }
        return nil
    }

    private func extractJSON(from text: String) -> String? {
        guard let s = text.range(of: "{"),
              let e = text.range(of: "}", options: .backwards) else { return nil }
        return String(text[s.lowerBound...e.upperBound])
    }

    private func detectRec(in text: String) -> Recommendation {
        let u = text.uppercased()
        if u.contains("BUY")  { return .buy  }
        if u.contains("SELL") { return .sell }
        if u.contains("MORE") { return .moreInfo }
        return .skip
    }
}

private struct ParsedAnalysis: Decodable {
    let recommendation: String?
    let confidence:     Double?
    let reasoning:      String?
    let key_signals:    [String]?

    enum CodingKeys: String, CodingKey {
        case recommendation
        case confidence
        case reasoning
        case key_signals
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.recommendation = try? container.decode(String.self, forKey: .recommendation)
        self.reasoning = try? container.decode(String.self, forKey: .reasoning)
        self.key_signals = try? container.decode([String].self, forKey: .key_signals)
        
        // Robust confidence decoding
        if let doubleVal = try? container.decode(Double.self, forKey: .confidence) {
            self.confidence = doubleVal
        } else if let stringVal = try? container.decode(String.self, forKey: .confidence),
                  let doubleVal = Double(stringVal) {
            self.confidence = doubleVal
        } else if let intVal = try? container.decode(Int.self, forKey: .confidence) {
            self.confidence = Double(intVal)
        } else {
            self.confidence = nil
        }
    }
}
