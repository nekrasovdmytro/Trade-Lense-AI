import SwiftUI

enum Recommendation: String, Codable, CaseIterable {
    case buy = "BUY"
    case sell = "SELL"
    case skip = "SKIP"
    case moreInfo = "MORE_INFO"

    var displayText: String {
        switch self {
        case .buy: "📈  BUY"
        case .sell: "📉  SELL"
        case .skip: "⏭  SKIP"
        case .moreInfo: "🔍  NEED MORE INFO"
        }
    }

    var color: Color {
        switch self {
        case .buy: .green
        case .sell: .red
        case .skip: .yellow
        case .moreInfo: .blue
        }
    }
}

struct AnalysisResult: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var timestamp: Date = Date()
    var recommendation: Recommendation
    var reasoning: String
    var confidence: Double?
    var keySignals: [String]?
    var rawResponse: String
    var screenshotData: Data?
    var isGeneralAnalysis: Bool = false
    var mode: TradingMode? = .indicator
}
