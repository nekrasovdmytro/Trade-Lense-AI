import Foundation

// MARK: - ProviderID

enum ProviderID: String, Codable, CaseIterable, Hashable {
    case ollama    = "ollama"
    case premium   = "premium"
    case nvidia    = "nvidia"
    case openai    = "openai"
    case anthropic = "anthropic"
    case groq      = "groq"

    var displayName: String {
        switch self {
        case .ollama:    "Ollama (Local)"
        case .premium:   "Premium VPS (Sub)"
        case .nvidia:    "NVIDIA NIM"
        case .openai:    "OpenAI"
        case .anthropic: "Anthropic"
        case .groq:      "Groq"
        }
    }

    var subtitle: String {
        switch self {
        case .ollama:    "Free · Runs on your Mac · No internet needed"
        case .premium:   "6.99€/mo · High-quality private model"
        case .nvidia:    "Free tier · GPU-accelerated cloud models"
        case .openai:    "Paid · GPT-4o family"
        case .anthropic: "Paid · Claude family"
        case .groq:      "Free tier · Ultra-fast inference"
        }
    }

    var isFree: Bool {
        switch self { case .ollama, .nvidia, .groq: true; default: false }
    }

    var requiresAPIKey: Bool { self != .ollama }

    var defaultBaseURL: String {
        switch self {
        case .ollama:    "http://localhost:11434"
        case .premium:   "https://api.yourwebsite.com/v1" // Placeholder for your VPS
        case .nvidia:    "https://integrate.api.nvidia.com/v1"
        case .openai:    "https://api.openai.com/v1"
        case .anthropic: "https://api.anthropic.com"
        case .groq:      "https://api.groq.com/openai/v1"
        }
    }

    var getKeyURL: String? {
        switch self {
        case .premium:   "https://yourwebsite.com/subscribe"
        case .nvidia:    "https://build.nvidia.com"
        case .openai:    "https://platform.openai.com/api-keys"
        case .anthropic: "https://console.anthropic.com/settings/keys"
        case .groq:      "https://console.groq.com/keys"
        case .ollama:    nil
        }
    }

    var icon: String {
        switch self {
        case .ollama:    "cpu"
        case .premium:   "star.fill"
        case .nvidia:    "bolt.circle.fill"
        case .openai:    "brain"
        case .anthropic: "sparkles"
        case .groq:      "hare.fill"
        }
    }

    // Vision-capable models for each provider
    var visionModels: [ModelOption] {
        switch self {
        case .premium:
            return [
                ModelOption(modelID: "premium-chart-v1", name: "Premium Vision 1.0", provider: self)
            ]
        case .ollama:
            var list = [
                ModelOption(modelID: "qwen2.5vl:3b",    name: "Qwen 2.5 VL 3B",   provider: self),
                ModelOption(modelID: "qwen2.5vl:7b",    name: "Qwen 2.5 VL 7B",   provider: self),
                ModelOption(modelID: "llava",            name: "LLaVA",             provider: self),
                ModelOption(modelID: "llava-llama3",     name: "LLaVA LLaMA 3",    provider: self),
                ModelOption(modelID: "llava-phi3",       name: "LLaVA Phi 3",      provider: self),
                ModelOption(modelID: "minicpm-v",        name: "MiniCPM-V",        provider: self),
                ModelOption(modelID: "moondream",        name: "Moondream",         provider: self),
            ]
            let custom = UserDefaults.standard.string(forKey: "customOllamaModel") ?? ""
            if !custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                list.append(ModelOption(modelID: custom.trimmingCharacters(in: .whitespacesAndNewlines), name: "Custom (\(custom))", provider: self))
            }
            return list
        case .nvidia:
            // Only models confirmed on the free-tier chat/completions endpoint
            var list = [
                ModelOption(modelID: "nvidia/nemotron-nano-12b-v2-vl",       name: "Nemotron Nano 12B VL",    provider: self),
                ModelOption(modelID: "meta/llama-3.2-11b-vision-instruct",   name: "Llama 3.2 11B Vision",    provider: self),
                ModelOption(modelID: "meta/llama-3.2-90b-vision-instruct",   name: "Llama 3.2 90B Vision",    provider: self),
                ModelOption(modelID: "microsoft/phi-3.5-vision-instruct",    name: "Phi 3.5 Vision",          provider: self),
            ]
            let custom = UserDefaults.standard.string(forKey: "customNvidiaModel") ?? ""
            if !custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                list.append(ModelOption(modelID: custom.trimmingCharacters(in: .whitespacesAndNewlines), name: "Custom (\(custom))", provider: self))
            }
            return list
        case .openai:
            return [
                ModelOption(modelID: "gpt-4o",      name: "GPT-4o",       provider: self),
                ModelOption(modelID: "gpt-4o-mini", name: "GPT-4o Mini",  provider: self),
                ModelOption(modelID: "gpt-4-turbo", name: "GPT-4 Turbo",  provider: self),
            ]
        case .anthropic:
            return [
                ModelOption(modelID: "claude-opus-4-7",            name: "Claude Opus 4.7",   provider: self),
                ModelOption(modelID: "claude-sonnet-4-6",          name: "Claude Sonnet 4.6", provider: self),
                ModelOption(modelID: "claude-haiku-4-5-20251001",  name: "Claude Haiku 4.5",  provider: self),
            ]
        case .groq:
            return [
                ModelOption(modelID: "llama-3.2-90b-vision-preview",                  name: "Llama 3.2 90B Vision", provider: self),
                ModelOption(modelID: "llama-3.2-11b-vision-preview",                  name: "Llama 3.2 11B Vision", provider: self),
                ModelOption(modelID: "meta-llama/llama-4-scout-17b-16e-instruct",     name: "Llama 4 Scout 17B",    provider: self),
            ]
        }
    }
}

// MARK: - ModelOption

struct ModelOption: Identifiable, Hashable, Codable {
    let modelID: String
    let name: String
    let provider: ProviderID
    var isTextOnly: Bool = false  // text-only models don't process images

    var id: String { "\(provider.rawValue)/\(modelID)" }
}

// MARK: - Text models (no vision)

extension ProviderID {
    var textModels: [ModelOption] {
        switch self {
        case .ollama:
            var list: [ModelOption] = [
                ModelOption(modelID: "llama3.2:3b",      name: "Llama 3.2 3B",       provider: self, isTextOnly: true),
                ModelOption(modelID: "llama3.2:1b",      name: "Llama 3.2 1B",       provider: self, isTextOnly: true),
                ModelOption(modelID: "llama3.1:8b",      name: "Llama 3.1 8B",       provider: self, isTextOnly: true),
                ModelOption(modelID: "mistral",           name: "Mistral 7B",         provider: self, isTextOnly: true),
                ModelOption(modelID: "gemma3:4b",         name: "Gemma 3 4B",         provider: self, isTextOnly: true),
                ModelOption(modelID: "phi4-mini",         name: "Phi 4 Mini",         provider: self, isTextOnly: true),
                ModelOption(modelID: "qwen2.5:7b",       name: "Qwen 2.5 7B",        provider: self, isTextOnly: true),
                ModelOption(modelID: "deepseek-r1:8b",   name: "DeepSeek R1 8B",     provider: self, isTextOnly: true),
            ]
            let custom = UserDefaults.standard.string(forKey: "customOllamaTextModel") ?? ""
            if !custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let c = custom.trimmingCharacters(in: .whitespacesAndNewlines)
                list.append(ModelOption(modelID: c, name: "Custom Text (\(c))", provider: self, isTextOnly: true))
            }
            return list
        case .nvidia:
            var list: [ModelOption] = [
                ModelOption(modelID: "meta/llama-3.1-8b-instruct",            name: "Llama 3.1 8B Instruct",   provider: self, isTextOnly: true),
                ModelOption(modelID: "meta/llama-3.3-70b-instruct",           name: "Llama 3.3 70B Instruct",  provider: self, isTextOnly: true),
                ModelOption(modelID: "nvidia/llama-3.1-nemotron-nano-8b-v1",  name: "Nemotron Nano 8B",        provider: self, isTextOnly: true),
                ModelOption(modelID: "mistralai/mistral-7b-instruct-v0.3",    name: "Mistral 7B Instruct",     provider: self, isTextOnly: true),
                ModelOption(modelID: "nvidia/llama-3.3-nemotron-super-49b-v1", name: "Nemotron Super 49B",     provider: self, isTextOnly: true),
            ]
            let custom = UserDefaults.standard.string(forKey: "customNvidiaTextModel") ?? ""
            if !custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let c = custom.trimmingCharacters(in: .whitespacesAndNewlines)
                list.append(ModelOption(modelID: c, name: "Custom Text (\(c))", provider: self, isTextOnly: true))
            }
            return list
        default:
            return []
        }
    }
}

// MARK: - All providers + models flat list

extension ProviderID {
    static var allModels: [ModelOption] {
        allCases.flatMap { $0.visionModels }
    }

    var allModels: [ModelOption] { visionModels + textModels }
}
