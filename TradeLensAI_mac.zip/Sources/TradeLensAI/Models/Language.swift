import Foundation

struct SupportedLanguage: Identifiable, Hashable {
    let id: String          // BCP-47 code used in the prompt
    let englishName: String
    let nativeName: String

    var label: String { "\(nativeName)  —  \(englishName)" }

    static let all: [SupportedLanguage] = [
        SupportedLanguage(id: "en", englishName: "English",    nativeName: "English"),
        SupportedLanguage(id: "uk", englishName: "Ukrainian",  nativeName: "Українська"),
        SupportedLanguage(id: "es", englishName: "Spanish",    nativeName: "Español"),
        SupportedLanguage(id: "fr", englishName: "French",     nativeName: "Français"),
        SupportedLanguage(id: "de", englishName: "German",     nativeName: "Deutsch"),
        SupportedLanguage(id: "it", englishName: "Italian",    nativeName: "Italiano"),
        SupportedLanguage(id: "pt", englishName: "Portuguese", nativeName: "Português"),
        SupportedLanguage(id: "ru", englishName: "Russian",    nativeName: "Русский"),
        SupportedLanguage(id: "pl", englishName: "Polish",     nativeName: "Polski"),
        SupportedLanguage(id: "nl", englishName: "Dutch",      nativeName: "Nederlands"),
        SupportedLanguage(id: "zh", englishName: "Chinese",    nativeName: "中文"),
        SupportedLanguage(id: "ja", englishName: "Japanese",   nativeName: "日本語"),
        SupportedLanguage(id: "ko", englishName: "Korean",     nativeName: "한국어"),
        SupportedLanguage(id: "ar", englishName: "Arabic",     nativeName: "العربية"),
        SupportedLanguage(id: "hi", englishName: "Hindi",      nativeName: "हिन्दी"),
        SupportedLanguage(id: "tr", englishName: "Turkish",    nativeName: "Türkçe"),
        SupportedLanguage(id: "vi", englishName: "Vietnamese", nativeName: "Tiếng Việt"),
        SupportedLanguage(id: "th", englishName: "Thai",       nativeName: "ภาษาไทย"),
        SupportedLanguage(id: "id", englishName: "Indonesian", nativeName: "Bahasa Indonesia"),
    ]

    static func name(for id: String) -> String {
        all.first { $0.id == id }?.englishName ?? id
    }

    // Detect macOS system language and fall back to English if not in our list
    static var systemDefault: SupportedLanguage {
        let code = Locale.current.language.languageCode?.identifier ?? "en"
        return all.first { $0.id == code } ?? all[0]
    }
}
