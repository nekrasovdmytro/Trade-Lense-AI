import SwiftUI

@main
struct TradeLensAIApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var settings = SettingsManager.shared

    var body: some Scene {
        Settings {
            EmptyView()
        }
        .environment(\.locale, .init(identifier: settings.appLanguageID))
    }
}
