import SwiftUI

struct FloatingPanelView: View {
    @ObservedObject var appState: AppState
    @ObservedObject var settings = SettingsManager.shared
    @State private var showHistory = false

    var body: some View {
        ZStack {
            // Clean, elegant background with a subtle tint
            Color(nsColor: .windowBackgroundColor)
                .ignoresSafeArea()
            
            // Subtle premium gradient at the top
            LinearGradient(
                colors: [
                    Color.accentColor.opacity(0.05),
                    Color.clear
                ],
                startPoint: .top,
                endPoint: .center
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                header
                    .padding(.bottom, 4)
                
                Divider().opacity(0.5)
                
                modeSelector
                    .padding(.vertical, 8)
                
                Divider().opacity(0.5)
                
                content
                
                Divider().opacity(0.5)
                
                // Spiritual message / Bible verse strip
                bibleVerseStrip
                
                Divider().opacity(0.5)
                
                chartToolbar
                
                Text(LocalizedStringKey("aiDisclaimer"))
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundStyle(.tertiary)
                    .padding(.vertical, 6)
                    .frame(maxWidth: .infinity)
                    .background(Color.black.opacity(0.02))
                
                Divider().opacity(0.5)
                askBar
            }
            
            if LicensingService.shared.isTrialExpired {
                licenseBlockingOverlay
            }
        }
        .frame(minWidth: 380, idealWidth: 400, maxWidth: 600, minHeight: 580)
        .sheet(isPresented: $showHistory) {
            HistoryView(appState: appState)
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.75), value: settings.selectedTradingModeID)
    }

    // MARK: - Spiritual Message
    
    private var bibleVerseStrip: some View {
        HStack(alignment: .top, spacing: 6) {
            Image(systemName: "heart.fill")
                .font(.system(size: 10))
                .foregroundColor(.red.opacity(0.7))
                .padding(.top, 2)
            Text(LocalizedStringKey("bibleVerse"))
                .font(.system(size: 10, weight: .semibold, design: .serif))
                .italic()
                .foregroundStyle(.secondary.opacity(0.8))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                colors: [Color.clear, Color.accentColor.opacity(0.03), Color.clear],
                startPoint: .leading,
                endPoint: .trailing
            )
        )
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            // Logo and Title Group
            HStack(spacing: 10) {
                // Programmatic ChristNote Logo
                ZStack {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 32, height: 32)
                    
                    Image(systemName: "cross.fill")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                        .shadow(radius: 1)
                }
                .shadow(color: .blue.opacity(0.2), radius: 4, x: 0, y: 2)
                
                VStack(alignment: .leading, spacing: 1) {
                    HStack(spacing: 6) {
                        Text(LocalizedStringKey("appName"))
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .foregroundStyle(.primary)
                            .fixedSize()
                        
                        Text("PRO")
                            .font(.system(size: 9, weight: .heavy, design: .rounded))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(
                                LinearGradient(colors: [.yellow, .orange], startPoint: .topLeading, endPoint: .bottomTrailing)
                            )
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            .shadow(color: .orange.opacity(0.3), radius: 2, x: 0, y: 1)
                    }
                    Text(LocalizedStringKey("byChristNote"))
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.secondary)
                        .fixedSize()
                }
            }
            .layoutPriority(1)
            
            Spacer(minLength: 4)
            
            // Pickers and buttons
            HStack(spacing: 8) {
                modelPicker
                
                Button {
                    SettingsWindowController.show(settings: settings)
                } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.secondary)
                        .frame(width: 26, height: 26)
                        .background(Color.secondary.opacity(0.1), in: Circle())
                }
                .buttonStyle(.plain)
                .help(Text(LocalizedStringKey("settings")))
            }
        }
        .padding(.horizontal, 12)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }

    private var licenseBlockingOverlay: some View {
        EmptyView()
    }

    private var modelPicker: some View {
        Menu {
            ForEach(ProviderID.allCases, id: \.self) { provider in
                let vModels = provider.visionModels
                let tModels = provider.textModels
                if !vModels.isEmpty || !tModels.isEmpty {
                    Section(provider.displayName) {
                        if !vModels.isEmpty {
                            ForEach(vModels) { model in
                                modelButton(model: model, provider: provider, label: "📷 \(model.name)")
                            }
                        }
                        if !tModels.isEmpty {
                            Divider()
                            ForEach(tModels) { model in
                                modelButton(model: model, provider: provider, label: "💬 \(model.name)")
                            }
                        }
                    }
                }
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: settings.selectedModel.isTextOnly ? "text.bubble.fill" : settings.selectedProviderID.icon)
                    .font(.system(size: 10))
                    .foregroundColor(.accentColor)
                Text(settings.selectedModel.name)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .lineLimit(1)
                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 8, weight: .bold))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
    }

    private func modelButton(model: ModelOption, provider: ProviderID, label: String) -> some View {
        Button {
            settings.select(provider: provider, model: model)
        } label: {
            let isActive = settings.selectedProviderID == provider && settings.selectedModelID == model.modelID
            Label(label, systemImage: isActive ? "checkmark" : "")
        }
    }

    // MARK: - Content

    @ViewBuilder
    private var content: some View {
        switch appState.analysisState {
        case .idle:
            idleView
        case .selectingRegion:
            progressView(LocalizedStringKey("drawRectangle"), icon: "selection.pin.in.out", color: .purple)
        case .capturing:
            progressView(LocalizedStringKey("capturingScreen"), icon: "camera.viewfinder", color: .blue)
        case .preparing:
            progressView(LocalizedStringKey("processing"), icon: "cpu", color: .teal)
        case .analyzing(let partial):
            if partial.isEmpty {
                progressView(LocalizedStringKey("analyzing"), icon: "waveform.path.ecg", color: .orange)
            } else {
                streamingResultView(partial)
            }
        case .result(let result):
            resultView(result)
        case .error(let msg):
            errorView(msg)
        }
    }

    private func streamingResultView(_ text: String) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 12) {
                    ProgressView()
                        .controlSize(.small)
                    Text(LocalizedStringKey("generatingInsights"))

                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button(action: { appState.stopAnalysis() }) {
                        Text(LocalizedStringKey("stop"))

                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(Color.red.opacity(0.8), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)
                
                Text(text)
                    .font(.system(size: 13, weight: .regular, design: .default))
                    .lineSpacing(4)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
            }
        }
    }

    private var idleView: some View {
        VStack(spacing: 24) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(colors: [Color.accentColor.opacity(0.1), Color.purple.opacity(0.1)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .frame(width: 100, height: 100)
                
                Image(systemName: settings.selectedModel.isTextOnly ? "text.bubble.fill" : "chart.line.uptrend.xyaxis")
                    .font(.system(size: 44, weight: .light))
                    .foregroundStyle(
                        LinearGradient(colors: [Color.accentColor, Color.purple], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
            }
            .shadow(color: Color.accentColor.opacity(0.1), radius: 10, x: 0, y: 5)
            
            VStack(spacing: 8) {
                if settings.selectedModel.isTextOnly {
                    Text(LocalizedStringKey("readyForQueries"))
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .foregroundStyle(.primary)
                    Text(LocalizedStringKey("visionSwitchHint"))
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .lineSpacing(2)
                    
                    if !appState.lastScreenContext.isEmpty {
                        HStack(spacing: 6) {
                            Image(systemName: "camera.macro")
                                .font(.system(size: 10))
                            Text(LocalizedStringKey("screenContextActive"))
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .foregroundColor(.accentColor)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.accentColor.opacity(0.1), in: Capsule())
                        .padding(.top, 8)
                    }
                } else {
                    Text(LocalizedStringKey("awaitingChart"))
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .foregroundStyle(.primary)
                    
                    HStack(spacing: 4) {
                        Text(LocalizedStringKey("press"))
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                        
                        HStack(spacing: 2) {
                            Image(systemName: "command")
                            Image(systemName: "shift")
                            Text("A")
                        }
                        .font(.system(size: 11, weight: .bold))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.secondary.opacity(0.15), in: RoundedRectangle(cornerRadius: 4))
                        .foregroundStyle(.primary)
                        
                        Text(LocalizedStringKey("toAnalyze"))
                            .font(.system(size: 12))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    private func progressView(_ text: LocalizedStringKey, icon: String, color: Color) -> some View {
        VStack(spacing: 24) {
            ZStack {
                Circle()
                    .stroke(color.opacity(0.2), lineWidth: 4)
                    .frame(width: 80, height: 80)
                
                Circle()
                    .trim(from: 0, to: 0.7)
                    .stroke(color, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                    .frame(width: 80, height: 80)
                    .rotationEffect(.degrees(-90))
                    .animation(Animation.linear(duration: 1.5).repeatForever(autoreverses: false), value: UUID())
                
                Image(systemName: icon)
                    .font(.system(size: 32, weight: .light))
                    .foregroundColor(color)
                    .symbolEffect(.pulse)
            }
            
            Text(text)
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    private func resultView(_ result: AnalysisResult) -> some View {
        ScrollView {
            VStack(spacing: 20) {
                if result.isGeneralAnalysis {
                    generalResultBody(result)
                } else {
                    chartResultBody(result)
                }
                
                HStack {
                    Spacer()
                    Text(result.timestamp.formatted(date: .abbreviated, time: .shortened))
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 20)
            }
            .padding(.vertical, 20)
        }
    }

    private func generalResultBody(_ result: AnalysisResult) -> some View {
        VStack(spacing: 16) {
            HStack(spacing: 10) {
                Image(systemName: "sparkles")
                    .foregroundColor(.accentColor)
                    .font(.system(size: 18))
                Text("AI Insight")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                Spacer()
            }
            .padding(.horizontal, 20)

            Text(result.reasoning)
                .font(.system(size: 14, weight: .regular))
                .lineSpacing(6)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
                .background(Color.secondary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
                )
                .padding(.horizontal, 16)
        }
    }

    private var modeSelector: some View {
        HStack(spacing: 8) {
            ForEach(TradingMode.allCases) { mode in
                Button {
                    settings.selectedTradingModeID = mode.rawValue
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: mode.iconName)
                            .font(.system(size: 12, weight: .semibold))
                        Text(mode.displayName)
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                    }
                    .foregroundColor(settings.selectedTradingMode == mode ? .white : .primary.opacity(0.7))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(
                        ZStack {
                            if settings.selectedTradingMode == mode {
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(modeColor(mode))
                                    .shadow(color: modeColor(mode).opacity(0.3), radius: 4, x: 0, y: 2)
                            } else {
                                RoundedRectangle(cornerRadius: 8, style: .continuous)
                                    .fill(Color.secondary.opacity(0.05))
                            }
                        }
                    )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
    }

    private func modeColor(_ mode: TradingMode) -> Color {
        switch mode {
        case .indicator: return .accentColor
        case .educator: return .orange
        case .riskAdvisor: return .teal
        }
    }

    private func indicatorResultCard(_ result: AnalysisResult) -> some View {
        VStack(spacing: 6) {
            Text("SIGNAL")
                .font(.system(size: 10, weight: .heavy, design: .rounded))
                .foregroundColor(.secondary.opacity(0.8))
                .tracking(2)
            
            Text(result.recommendation.displayText)
                .font(.system(size: 28, weight: .heavy, design: .rounded))
                .padding(.horizontal, 32)
                .padding(.vertical, 12)
                .background(
                    ZStack {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(result.recommendation.color.opacity(0.15))
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .strokeBorder(result.recommendation.color.opacity(0.4), lineWidth: 2)
                    }
                )
                .foregroundColor(result.recommendation.color)
                .shadow(color: result.recommendation.color.opacity(0.25), radius: 10, x: 0, y: 5)
        }
        .frame(maxWidth: .infinity)
    }

    private func educatorResultCard(_ result: AnalysisResult) -> some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.orange.opacity(0.2))
                    .frame(width: 48, height: 48)
                Image(systemName: "graduationcap.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.orange)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("EDUCATOR MODE")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .foregroundColor(.orange)
                    .tracking(1.5)
                Text("Comprehensive Chart Breakdown")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.primary)
            }
            Spacer()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.orange.opacity(0.05))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(Color.orange.opacity(0.15), lineWidth: 1)
        )
        .padding(.horizontal, 16)
    }

    private func riskAdvisorResultCard(_ result: AnalysisResult) -> some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.teal.opacity(0.2))
                    .frame(width: 48, height: 48)
                Image(systemName: "shield.lefthalf.filled")
                    .font(.system(size: 20))
                    .foregroundColor(.teal)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("RISK ADVISOR")
                    .font(.system(size: 11, weight: .heavy, design: .rounded))
                    .foregroundColor(.teal)
                    .tracking(1.5)
                Text("Risk Assessment & Key Levels")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.primary)
            }
            Spacer()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.teal.opacity(0.05))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(Color.teal.opacity(0.15), lineWidth: 1)
        )
        .padding(.horizontal, 16)
    }

    private func chartResultBody(_ result: AnalysisResult) -> some View {
        let isNotChart = result.recommendation == .skip &&
            (result.reasoning.lowercased().contains("not a chart") ||
             result.reasoning.lowercased().contains("not a trading chart"))
        
        let mode = result.mode ?? .indicator

        return VStack(spacing: 20) {
            if isNotChart {
                HStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.yellow)
                    VStack(alignment: .leading) {
                        Text("Not a valid chart")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                        Text("Please capture a trading chart for analysis.")
                            .font(.system(size: 12))
                            .foregroundColor(.secondary)
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .padding(.horizontal, 16)
            } else {
                switch mode {
                case .indicator:
                    indicatorResultCard(result)
                case .educator:
                    educatorResultCard(result)
                case .riskAdvisor:
                    riskAdvisorResultCard(result)
                }
            }

            if !isNotChart && mode == .indicator, let confidence = result.confidence {
                VStack(spacing: 8) {
                    HStack {
                        Text("Confidence Level")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text("\(Int(confidence * 100))%")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(result.recommendation.color)
                    }
                    
                    GeometryReader { geometry in
                        ZStack(alignment: .leading) {
                            Capsule()
                                .fill(Color.secondary.opacity(0.15))
                                .frame(height: 6)
                            Capsule()
                                .fill(result.recommendation.color)
                                .frame(width: geometry.size.width * CGFloat(confidence), height: 6)
                        }
                    }
                    .frame(height: 6)
                }
                .padding(.horizontal, 32)
            }

            if let signals = result.keySignals, !signals.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    Text(mode == .educator ? "Key Observations" : (mode == .riskAdvisor ? "Critical Metrics" : "Technical Signals"))
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(signals, id: \.self) { signal in
                            HStack(alignment: .top, spacing: 8) {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 12))
                                    .foregroundColor(modeColor(mode))
                                    .padding(.top, 2)
                                Text(signal)
                                    .font(.system(size: 13, weight: .medium))
                                    .foregroundStyle(.primary)
                            }
                        }
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(modeColor(mode).opacity(0.05))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(modeColor(mode).opacity(0.1), lineWidth: 1)
                )
                .padding(.horizontal, 16)
            }

            Text(result.reasoning)
                .font(.system(size: 14, weight: .regular))
                .lineSpacing(6)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)
        }
    }

    private func errorView(_ message: String) -> some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .fill(message.contains("GDPR") ? Color.blue.opacity(0.15) : Color.red.opacity(0.15))
                    .frame(width: 80, height: 80)
                
                Image(systemName: message.contains("GDPR") ? "shield.checkerboard" : "exclamationmark.triangle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(message.contains("GDPR") ? .blue : .red)
            }
            
            Text(message)
                .font(.system(size: 13, weight: .medium))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)
            
            if message.contains("GDPR") {
                Button(action: {
                    settings.isCloudConsentGiven = true
                    Task { await appState.captureAndAnalyze() }
                }) {
                    Text("Accept GDPR Consent")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.blue, in: Capsule())
                }
                .buttonStyle(.plain)
            } else {
                Button(action: {
                    Task { await appState.captureAndAnalyze() }
                }) {
                    Text(LocalizedStringKey("tryAgain"))

                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.accentColor, in: Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    // MARK: - Chart toolbar

    private var chartToolbar: some View {
        VStack(spacing: 12) {
            if settings.selectedModel.isTextOnly {
                HStack(spacing: 8) {
                    Image(systemName: "info.circle.fill")
                        .foregroundColor(.orange)
                        .font(.system(size: 14))
                    Text("Vision model required for full chart analysis")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.orange)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            } else {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                        .font(.system(size: 12))
                    
                    TextField("Specific instructions or focus (optional)…", text: $appState.specificInstructions)
                        .textFieldStyle(.plain)
                        .font(.system(size: 13))
                    
                    if !appState.specificInstructions.isEmpty {
                        Button(action: { appState.specificInstructions = "" }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
                )
            }

            HStack(spacing: 12) {
                Button(action: { showHistory = true }) {
                    Image(systemName: "clock.arrow.circlepath")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.secondary)
                        .frame(width: 32, height: 32)
                        .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                }
                .buttonStyle(.plain)
                .help(Text(LocalizedStringKey("history")))

                if case .result = appState.analysisState {
                    Button(action: appState.reset) {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.secondary)
                            .frame(width: 32, height: 32)
                            .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .help(Text(LocalizedStringKey("reset")))
                }

                Spacer()

                Button(action: { Task { await appState.captureAndAnalyze() } }) {
                    HStack(spacing: 6) {
                        Image(systemName: "display")
                        Text(LocalizedStringKey("fullScreen"))
                    }
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(settings.selectedModel.isTextOnly ? .secondary : .primary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(appState.isAnalyzing || settings.selectedModel.isTextOnly)

                Button(action: { appState.onRequestRegionSelection?() }) {
                    HStack(spacing: 6) {
                        Image(systemName: "crop")
                        Text(LocalizedStringKey("selectRegion"))
                    }
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(
                        settings.selectedModel.isTextOnly ? Color.secondary.opacity(0.5) : Color.accentColor,
                        in: RoundedRectangle(cornerRadius: 8, style: .continuous)
                    )
                    .shadow(color: settings.selectedModel.isTextOnly ? .clear : Color.accentColor.opacity(0.3), radius: 4, x: 0, y: 2)
                }
                .buttonStyle(.plain)
                .disabled(appState.isAnalyzing || settings.selectedModel.isTextOnly)
                .keyboardShortcut("a", modifiers: [.command, .shift])
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    // MARK: - Ask bar

    private var askBar: some View {
        VStack(spacing: 0) {
            // Live transcript strip
            if !appState.speechLiveText.isEmpty {
                HStack(spacing: 8) {
                    Image(systemName: "waveform")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.red)
                        .symbolEffect(.pulse)
                    Text(appState.speechLiveText)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(Color.red.opacity(0.1))
                Divider().opacity(0.5)
            }

            HStack(spacing: 10) {
                // Mic button
                Button(action: { appState.toggleRecording() }) {
                    ZStack {
                        Circle()
                            .fill(appState.isRecording ? Color.red.opacity(0.2) : Color.secondary.opacity(0.1))
                            .frame(width: 32, height: 32)
                        
                        Image(systemName: appState.isRecording ? "stop.fill" : "mic.fill")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(appState.isRecording ? .red : .secondary)
                            .symbolEffect(.pulse, isActive: appState.isRecording)
                    }
                }
                .buttonStyle(.plain)
                .help(appState.isRecording ? LocalizedStringKey("stopRecording") : LocalizedStringKey("recordVoice"))

                TextField(
                    settings.selectedModel.isTextOnly ? LocalizedStringKey("askAI") : LocalizedStringKey("askAboutScreen"),
                    text: $appState.customPrompt
                )
                .textFieldStyle(.plain)
                .font(.system(size: 13))
                .padding(.vertical, 8)
                .padding(.horizontal, 12)
                .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
                )
                .onSubmit { Task { await appState.askAboutScreen() } }

                if !settings.selectedModel.isTextOnly {
                    HStack(spacing: 4) {
                        Button(action: { Task { await appState.askAboutScreen() } }) {
                            Image(systemName: "display")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                        }
                        .buttonStyle(.plain)
                        .help(LocalizedStringKey("askAboutFull"))
                        .disabled(appState.isAnalyzing)

                        Button(action: { appState.onRequestRegionSelectionForAsk?() }) {
                            Image(systemName: "crop")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 28, height: 28)
                                .background(Color.accentColor, in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                        }
                        .buttonStyle(.plain)
                        .help(LocalizedStringKey("askAboutRegion"))
                        .disabled(appState.isAnalyzing)
                    }
                } else {
                    Button(action: { Task { await appState.askAboutScreen() } }) {
                        Image(systemName: "arrow.up")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 32, height: 32)
                            .background(
                                appState.customPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? Color.secondary.opacity(0.5) : Color.accentColor,
                                in: RoundedRectangle(cornerRadius: 8, style: .continuous)
                            )
                    }
                    .buttonStyle(.plain)
                    .help(LocalizedStringKey("send"))
                    .disabled(appState.isAnalyzing || appState.customPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.secondary.opacity(0.05))
        }
    }
}
