import AppKit
import SwiftUI

class FloatingPanel: NSPanel {
    init(contentView: NSView) {
        super.init(
            contentRect: NSRect(x: 0, y: 0, width: 400, height: 600),
            styleMask: [.titled, .closable, .resizable, .nonactivatingPanel, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )

        level = .floating
        collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary]
        isReleasedWhenClosed = false
        isMovableByWindowBackground = true
        titleVisibility = .hidden
        titlebarAppearsTransparent = true
        hasShadow = true
        
        backgroundColor = .clear
        isOpaque = false
        
        // Initial transparency state (very transparent when starting/inactive)
        self.alphaValue = 0.15 

        self.contentView = contentView

        // Position: top-right corner of main screen
        if let screen = NSScreen.main {
            let x = screen.visibleFrame.maxX - frame.width - 24
            let y = screen.visibleFrame.maxY - frame.height - 24
            setFrameOrigin(NSPoint(x: x, y: y))
        } else {
            center()
        }
        
        setupObservers()
    }

    override var canBecomeKey: Bool { true }
    
    private func setupObservers() {
        NotificationCenter.default.addObserver(forName: NSWindow.didBecomeKeyNotification, object: self, queue: .main) { [weak self] _ in
            self?.animator().alphaValue = 1.0
        }
        
        NotificationCenter.default.addObserver(forName: NSWindow.didResignKeyNotification, object: self, queue: .main) { [weak self] _ in
            self?.animator().alphaValue = 0.15
        }
    }
}
