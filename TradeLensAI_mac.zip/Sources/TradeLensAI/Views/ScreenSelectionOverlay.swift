import AppKit

class ScreenSelectionOverlay: NSWindow {
    var onSelection: ((CGRect, NSScreen) -> Void)?
    var onCancel:    (() -> Void)?

    private let selectionView: SelectionView
    private let targetScreen:  NSScreen

    init(screen: NSScreen = NSScreen.main ?? NSScreen.screens[0]) {
        targetScreen = screen
        // Frame relative to screen — origin always zero for the view
        let size = screen.frame.size
        selectionView = SelectionView(frame: NSRect(origin: .zero, size: size))

        super.init(
            contentRect: NSRect(origin: screen.frame.origin, size: size),
            styleMask:   [.borderless],
            backing:     .buffered,
            defer:       false
        )

        level                = .screenSaver
        backgroundColor      = .clear
        isOpaque             = false
        hasShadow            = false
        ignoresMouseEvents   = false
        acceptsMouseMovedEvents = true
        collectionBehavior   = [.canJoinAllSpaces, .fullScreenAuxiliary]
        isReleasedWhenClosed = false

        contentView = selectionView
        selectionView.onSelection = { [weak self] viewRect in self?.commitSelection(viewRect: viewRect) }
        selectionView.onCancel    = { [weak self] in self?.dismiss(cancelled: true) }
    }

    func show() {
        // Accessory apps need explicit activation so makeKeyAndOrderFront works
        NSApp.activate(ignoringOtherApps: true)
        makeKeyAndOrderFront(nil)
        NSCursor.crosshair.set()
    }

    private func commitSelection(viewRect: NSRect) {
        // viewRect is in AppKit view coords: bottom-left origin, screen-local, points.
        // SCStreamConfiguration.sourceRect expects: top-left origin, display-local, points (no scaling).
        let sourceRect = CGRect(
            x:      viewRect.origin.x,
            y:      targetScreen.frame.height - viewRect.maxY,
            width:  viewRect.width,
            height: viewRect.height
        )

        dismiss(cancelled: false)
        onSelection?(sourceRect, targetScreen)
    }

    private func dismiss(cancelled: Bool) {
        close()
        NSCursor.arrow.set()
        if cancelled { onCancel?() }
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { dismiss(cancelled: true) }  // Esc
    }

    override var canBecomeKey:  Bool { true }
    override var canBecomeMain: Bool { true }
}

// MARK: - SelectionView

class SelectionView: NSView {
    var onSelection: ((NSRect) -> Void)?
    var onCancel:    (() -> Void)?

    private var startPoint:    NSPoint?
    private var selectionRect: NSRect = .zero

    override func mouseDown(with event: NSEvent) {
        startPoint    = convert(event.locationInWindow, from: nil)
        selectionRect = .zero
        needsDisplay  = true
    }

    override func mouseDragged(with event: NSEvent) {
        guard let start = startPoint else { return }
        let cur = convert(event.locationInWindow, from: nil)
        selectionRect = NSRect(
            x: min(start.x, cur.x), y: min(start.y, cur.y),
            width:  abs(cur.x - start.x),
            height: abs(cur.y - start.y)
        )
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        if selectionRect.width > 20 && selectionRect.height > 20 {
            onSelection?(selectionRect)
        } else {
            startPoint    = nil
            selectionRect = .zero
            needsDisplay  = true
        }
    }

    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }

        ctx.setFillColor(NSColor.black.withAlphaComponent(0.45).cgColor)
        ctx.fill(bounds)

        if selectionRect != .zero {
            ctx.setBlendMode(.clear);  ctx.fill(selectionRect)
            ctx.setBlendMode(.normal)
            ctx.setStrokeColor(NSColor.white.cgColor)
            ctx.setLineWidth(1.5)
            ctx.stroke(selectionRect.insetBy(dx: -0.75, dy: -0.75))
            drawCorners(ctx: ctx)
            drawDimensions(ctx: ctx)
        } else {
            drawInstructions(ctx: ctx)
        }
    }

    private func drawCorners(ctx: CGContext) {
        let s: CGFloat = 6
        [NSRect(x: selectionRect.minX - s/2, y: selectionRect.minY - s/2, width: s, height: s),
         NSRect(x: selectionRect.maxX - s/2, y: selectionRect.minY - s/2, width: s, height: s),
         NSRect(x: selectionRect.minX - s/2, y: selectionRect.maxY - s/2, width: s, height: s),
         NSRect(x: selectionRect.maxX - s/2, y: selectionRect.maxY - s/2, width: s, height: s)]
        .forEach { ctx.setFillColor(NSColor.white.cgColor); ctx.fill($0) }
    }

    private func drawDimensions(ctx: CGContext) {
        let label = " \(Int(selectionRect.width)) × \(Int(selectionRect.height)) "
        let attrs: [NSAttributedString.Key: Any] = [
            .font: NSFont.monospacedSystemFont(ofSize: 12, weight: .medium),
            .foregroundColor: NSColor.white,
            .backgroundColor: NSColor.black.withAlphaComponent(0.65),
        ]
        let str = NSAttributedString(string: label, attributes: attrs)
        let sz  = str.size()
        let y   = max(4, selectionRect.minY - sz.height - 6)
        str.draw(at: NSPoint(x: selectionRect.midX - sz.width / 2, y: y))
    }

    private func drawInstructions(ctx: CGContext) {
        let label = "  Drag to select an area   ·   Esc to cancel  "
        let attrs: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 15, weight: .medium),
            .foregroundColor: NSColor.white,
            .backgroundColor: NSColor.black.withAlphaComponent(0.55),
        ]
        let str = NSAttributedString(string: label, attributes: attrs)
        let sz  = str.size()
        str.draw(at: NSPoint(x: bounds.midX - sz.width / 2, y: bounds.midY - sz.height / 2))
    }

    override func resetCursorRects() { addCursorRect(bounds, cursor: .crosshair) }
}
