import SwiftUI

private enum SettingsSection: Hashable {
    case general
    case provider(ProviderID)
    case license
}

struct SettingsView: View {
    @ObservedObject var settings: SettingsManager
    @State private var section: SettingsSection = .general
    @State private var testResult: TestResult?
    @State private var testing = false
    @State private var activationCode: String = ""
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationSplitView {
            sidebar
        } detail: {
            ZStack {
                Color(nsColor: .windowBackgroundColor).ignoresSafeArea()
                
                switch section {
                case .general:          generalDetail
                case .provider(let p):  providerDetail(p).id(p)
                case .license:          licenseDetail
                }
            }
        }
        .frame(minWidth: 700, minHeight: 550)
        .onChange(of: section) { testResult = nil }
    }

    // MARK: - Sidebar
    private var sidebar: some View {
        List(selection: $section) {
            Label(LocalizedStringKey("generalSettings"), systemImage: "gearshape.fill")
                .tag(SettingsSection.general)
            
            Section(LocalizedStringKey("aiProviders")) {
                ForEach(ProviderID.allCases, id: \.self) { provider in
                    ProviderRow(provider: provider, isConfigured: settings.isConfigured(provider))
                        .tag(SettingsSection.provider(provider))
                }
            }
            
            Section(LocalizedStringKey("account")) {
                Label(LocalizedStringKey("license"), systemImage: "key.fill")
                    .tag(SettingsSection.license)
            }
        }
        .listStyle(.sidebar)
        .navigationTitle(LocalizedStringKey("preferences"))
        .toolbar {
            ToolbarItem(placement: .automatic) {
                Button(LocalizedStringKey("done")) { dismiss() }
            }
        }
    }

    // MARK: - License detail
    private var licenseDetail: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                HStack(spacing: 16) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(LinearGradient(colors: [.yellow, .orange], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 64, height: 64)
                        
                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("ChristNote PRO").font(.system(size: 24, weight: .bold, design: .rounded))
                        Text("Lifetime Access Activated").font(.system(size: 14)).foregroundStyle(.secondary)
                    }
                }

                Divider()

                VStack(alignment: .leading, spacing: 16) {
                    HStack(spacing: 12) {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                            .font(.system(size: 20))
                        VStack(alignment: .leading, spacing: 2) {
                            Text("All Features Unlocked")
                                .font(.system(size: 16, weight: .semibold))
                            Text("You have full access to all trading modes and local AI integration.")
                                .font(.system(size: 13))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.yellow.opacity(0.1), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .strokeBorder(Color.yellow.opacity(0.2), lineWidth: 1)
                    )
                }
            }
            .padding(32)
        }
    }

    // MARK: - General detail
    private var generalDetail: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                // Header
                HStack(spacing: 16) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 64, height: 64)
                        
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 32))
                            .foregroundColor(.white)
                    }
                    VStack(alignment: .leading, spacing: 4) {
                        Text(LocalizedStringKey("generalSettings")).font(.system(size: 24, weight: .bold, design: .rounded))
                        Text(LocalizedStringKey("globalPreferencesDesc")).font(.system(size: 14)).foregroundStyle(.secondary)
                    }
                }

                Divider()

                // Settings Form
                VStack(spacing: 24) {
                    settingRow(
                        title: LocalizedStringKey("appInterfaceLanguage"),
                        icon: "character.bubble.fill",
                        color: .orange,
                        description: LocalizedStringKey("appInterfaceLanguageDesc")
                    ) {
                        Picker("", selection: $settings.appLanguageID) {
                            ForEach(SupportedLanguage.all.filter { ["en", "uk", "ru", "de"].contains($0.id) }) { lang in
                                Text(lang.label).tag(lang.id)
                            }
                        }
                        .labelsHidden()
                        .frame(width: 200)
                    }

                    settingRow(
                        title: LocalizedStringKey("responseLanguage"),
                        icon: "globe",
                        color: .blue,
                        description: LocalizedStringKey("responseLanguageDesc")
                    ) {
                        Picker("", selection: $settings.responseLanguageID) {
                            ForEach(SupportedLanguage.all) { lang in
                                Text(lang.label).tag(lang.id)
                            }
                        }
                        .labelsHidden()
                        .frame(width: 200)
                    }
                    
                    settingRow(
                        title: LocalizedStringKey("voiceLanguage"),
                        icon: "mic.fill",
                        color: .red,
                        description: LocalizedStringKey("voiceLanguageDesc")
                    ) {
                        Picker("", selection: $settings.speechLanguageID) {
                            ForEach(SupportedLanguage.all) { lang in
                                Text(lang.label).tag(lang.id)
                            }
                        }
                        .labelsHidden()
                        .frame(width: 200)
                    }
                    
                    settingRow(
                        title: LocalizedStringKey("gdprConsent"),
                        icon: "shield.checkered",
                        color: .teal,
                        description: LocalizedStringKey("gdprConsentDesc")
                    ) {
                        Toggle("", isOn: $settings.isCloudConsentGiven)
                            .labelsHidden()
                            .toggleStyle(.switch)
                    }
                }
            }
            .padding(32)
        }
    }

    private func settingRow<Content: View>(title: LocalizedStringKey, icon: String, color: Color, description: LocalizedStringKey, @ViewBuilder content: () -> Content) -> some View {
        HStack(alignment: .top, spacing: 16) {
            ZStack {
                Circle()
                    .fill(color.opacity(0.2))
                    .frame(width: 36, height: 36)
                Image(systemName: icon)
                    .foregroundColor(color)
                    .font(.system(size: 16))
            }
            
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(title)
                        .font(.system(size: 15, weight: .semibold))
                    Spacer()
                    content()
                }
                
                Text(description)
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(2)
            }
        }
        .padding(16)
        .background(Color.secondary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
        )
    }

    // MARK: - Detail
    @ViewBuilder
    private func providerDetail(_ provider: ProviderID) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                providerHeader(provider)
                
                Divider()
                
                if provider == .ollama {
                    ollamaSection
                } else if provider == .premium {
                    premiumSection
                } else {
                    apiKeySection(provider)
                }

                if provider != .ollama {
                    cloudConsentSection
                }

                testSection(provider)
                
                Divider()
                
                modelSection(provider)
            }
            .padding(32)
        }
    }

    // MARK: - Premium Section
    private var premiumSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)
                    .font(.system(size: 20))
                Text("Premium Cloud Engine")
                    .font(.system(size: 16, weight: .bold))
            }
            
            VStack(alignment: .leading, spacing: 16) {
                Text("Access high-performance private cloud models without local setup.")
                    .font(.system(size: 14))
                
                VStack(alignment: .leading, spacing: 12) {
                    premiumPerk(title: "Zero Setup Required", icon: "bolt.fill")
                    premiumPerk(title: "Blazing Fast Execution", icon: "timer")
                    premiumPerk(title: "Battery Friendly", icon: "battery.100")
                }
            }
            .padding(20)
            .background(Color.yellow.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(Color.yellow.opacity(0.2), lineWidth: 1)
            )
            
            VStack(alignment: .leading, spacing: 8) {
                Text("API Key:")
                    .font(.system(size: 13, weight: .bold))
                APIKeyField(provider: .premium, settings: settings)
            }
            .padding(.top, 8)
        }
    }

    private func premiumPerk(title: String, icon: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.yellow)
                .frame(width: 20)
            Text(title)
                .font(.system(size: 13, weight: .medium))
        }
    }

    private var cloudConsentSection: some View {
        HStack(spacing: 12) {
            Image(systemName: "shield.checkered")
                .foregroundColor(.teal)
                .font(.system(size: 20))
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Cloud Data Consent")
                    .font(.system(size: 14, weight: .semibold))
                Text("Transmission required for cloud processing.")
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            Toggle("", isOn: $settings.isCloudConsentGiven)
                .labelsHidden()
                .toggleStyle(.switch)
        }
        .padding(16)
        .background(Color.teal.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    // MARK: - Provider header
    private func providerHeader(_ provider: ProviderID) -> some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.secondary.opacity(0.1))
                    .frame(width: 64, height: 64)
                
                Image(systemName: provider.icon)
                    .font(.system(size: 32))
                    .foregroundColor(section == .provider(provider) ? .accentColor : .primary)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 8) {
                    Text(provider.displayName).font(.system(size: 24, weight: .bold, design: .rounded))
                    if provider.isFree {
                        Text("FREE")
                            .font(.system(size: 10, weight: .bold))
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(Color.green.opacity(0.2))
                            .foregroundColor(.green)
                            .clipShape(Capsule())
                    }
                }
                Text(provider.subtitle).font(.system(size: 14)).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - Ollama section
    private var ollamaSection: some View {
        VStack(spacing: 20) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Local Endpoint URL")
                    .font(.system(size: 13, weight: .bold))
                TextField("http://localhost:11434", text: $settings.ollamaBaseURL)
                    .textFieldStyle(.plain)
                    .font(.system(.body, design: .monospaced))
                    .padding(10)
                    .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8))
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Custom Model Tag (Optional)")
                    .font(.system(size: 13, weight: .bold))
                TextField("e.g. llama3.2-vision", text: $settings.customOllamaModel)
                    .textFieldStyle(.plain)
                    .padding(10)
                    .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8))
            }
        }
        .padding(20)
        .background(Color.secondary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: - API key section
    private func apiKeySection(_ provider: ProviderID) -> some View {
        VStack(spacing: 20) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("API Key")
                        .font(.system(size: 13, weight: .bold))
                    Spacer()
                    if let url = provider.getKeyURL {
                        Link(destination: URL(string: url)!) {
                            Text("Get API Key ↗")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.accentColor)
                        }
                    }
                }
                APIKeyField(provider: provider, settings: settings)
            }
            
            if provider == .nvidia {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Custom Model Name (Optional)")
                        .font(.system(size: 13, weight: .bold))
                    TextField("e.g. nvidia/grusa-vision", text: $settings.customNvidiaModel)
                        .textFieldStyle(.plain)
                        .padding(10)
                        .background(Color.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 8))
                }
            }
        }
        .padding(20)
        .background(Color.secondary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    // MARK: - Test connection section
    private func testSection(_ provider: ProviderID) -> some View {
        HStack(spacing: 16) {
            Button {
                Task { await runTest(provider) }
            } label: {
                HStack {
                    if testing {
                        ProgressView().controlSize(.small)
                        Text("Testing...")
                    } else {
                        Image(systemName: "bolt.horizontal.fill")
                        Text("Test Connection")
                    }
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(testing ? Color.secondary : Color.accentColor, in: Capsule())
            }
            .buttonStyle(.plain)
            .disabled(testing || (!settings.isConfigured(provider) && provider != .ollama))

            if let result = testResult {
                HStack(spacing: 8) {
                    Image(systemName: result.success ? "checkmark.circle.fill" : "xmark.circle.fill")
                        .foregroundColor(result.success ? .green : .red)
                    Text(result.message)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(result.success ? AnyShapeStyle(Color.green) : AnyShapeStyle(Color.red))
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background((result.success ? Color.green : Color.red).opacity(0.1), in: Capsule())
            }
        }
    }

    // MARK: - Model section
    private func modelSection(_ provider: ProviderID) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            let vModels = provider.visionModels
            let tModels = provider.textModels

            if !vModels.isEmpty {
                Text("Vision Models")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                
                VStack(spacing: 8) {
                    ForEach(vModels) { model in
                        ModelRow(
                            model: model,
                            isSelected: settings.selectedProviderID == provider && settings.selectedModelID == model.modelID
                        ) { settings.select(provider: provider, model: model) }
                    }
                }
            }

            if !tModels.isEmpty {
                Text("Text Models")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                    .padding(.top, vModels.isEmpty ? 0 : 8)
                
                VStack(spacing: 8) {
                    ForEach(tModels) { model in
                        ModelRow(
                            model: model,
                            isSelected: settings.selectedProviderID == provider && settings.selectedModelID == model.modelID
                        ) { settings.select(provider: provider, model: model) }
                    }
                }
            }
        }
    }

    // MARK: - Test logic
    private func runTest(_ provider: ProviderID) async {
        testing = true
        testResult = nil

        let result: (ok: Bool, message: String)

        switch provider {
        case .ollama:
            result = await OllamaService(baseURL: settings.ollamaBaseURL).testConnection()

        case .anthropic:
            guard let key = settings.apiKey(for: .anthropic) else {
                testResult = TestResult(success: false, message: "No API key set.")
                testing = false
                return
            }
            let model = settings.selectedProviderID == .anthropic
                      ? settings.selectedModelID
                      : provider.visionModels[0].modelID
            result = await AnthropicService(apiKey: key).testConnection(modelID: model)

        case .nvidia, .openai, .groq, .premium:
            guard let key = settings.apiKey(for: provider) else {
                testResult = TestResult(success: false, message: "No API key set.")
                testing = false
                return
            }
            let model = settings.selectedProviderID == provider
                      ? settings.selectedModelID
                      : provider.visionModels[0].modelID
            result = await OpenAICompatibleService(
                baseURL: provider.defaultBaseURL, apiKey: key, provider: provider
            ).testConnection(modelID: model)
        }

        testResult = TestResult(success: result.ok, message: result.message)
        testing = false
    }
}

private struct TestResult {
    let success: Bool
    let message: String
}

// MARK: - ProviderRow

struct ProviderRow: View {
    let provider: ProviderID
    let isConfigured: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: provider.icon)
                .frame(width: 24)
                .font(.system(size: 16))
                .foregroundColor(isConfigured ? .primary : .secondary)
            
            Text(provider.displayName)
                .font(.system(size: 14, weight: .medium))
            
            Spacer()
            
            Circle()
                .fill(isConfigured ? Color.green : Color.secondary.opacity(0.3))
                .frame(width: 8, height: 8)
        }
        .padding(.vertical, 6)
    }
}

// MARK: - APIKeyField

struct APIKeyField: View {
    let provider: ProviderID
    @ObservedObject var settings: SettingsManager
    @State private var editing = false
    @State private var draft   = ""

    private var hasKey: Bool { settings.isConfigured(provider) }

    var body: some View {
        if editing {
            HStack {
                SecureField("Paste your API key…", text: $draft)
                    .textFieldStyle(.plain)
                    .font(.system(.body, design: .monospaced))
                    .padding(8)
                    .background(Color(nsColor: .textBackgroundColor), in: RoundedRectangle(cornerRadius: 6))
                    .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Color.accentColor, lineWidth: 1))
                
                Button("Save") {
                    settings.setAPIKey(draft, for: provider)
                    editing = false; draft = ""
                }
                .buttonStyle(.borderedProminent)
                .disabled(draft.trimmingCharacters(in: .whitespaces).isEmpty)
                
                Button("Cancel") { editing = false; draft = "" }
                    .buttonStyle(.bordered)
            }
        } else {
            HStack {
                if hasKey {
                    Text("••••••••••••••••••••")
                        .font(.system(size: 14, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .padding(.vertical, 6)
                    Spacer()
                    Button("Remove") { settings.setAPIKey("", for: provider) }
                        .buttonStyle(.plain)
                        .foregroundColor(.red)
                        .font(.system(size: 12, weight: .semibold))
                        .padding(.trailing, 8)
                    Button("Replace") { editing = true }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                } else {
                    Text("Not configured")
                        .font(.system(size: 14))
                        .foregroundStyle(.secondary)
                        .padding(.vertical, 6)
                    Spacer()
                    Button("Add Key") { editing = true }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.small)
                }
            }
            .padding(10)
            .background(Color(nsColor: .textBackgroundColor), in: RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Color.secondary.opacity(0.2), lineWidth: 1))
        }
    }
}

// MARK: - ModelRow

struct ModelRow: View {
    let model: ModelOption
    let isSelected: Bool
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            HStack(spacing: 12) {
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(isSelected ? .accentColor : .secondary.opacity(0.5))
                    .font(.system(size: 16))
                
                Text(model.name)
                    .font(.system(size: 14, weight: isSelected ? .bold : .medium))
                    .foregroundColor(isSelected ? .primary : .secondary)
                
                Spacer()
                
                Text(model.modelID)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }
            .padding(.vertical, 10)
            .padding(.horizontal, 16)
            .background(
                isSelected ? Color.accentColor.opacity(0.1) : Color.secondary.opacity(0.05),
                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(isSelected ? Color.accentColor.opacity(0.3) : Color.secondary.opacity(0.1), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Settings Window

class SettingsWindowController {
    static func show(settings: SettingsManager) {
        let view   = SettingsView(settings: settings)
        let host   = NSHostingController(rootView: view)
        let window = NSWindow(contentViewController: host)
        window.title = "Preferences"
        window.styleMask = [.titled, .closable, .resizable, .fullSizeContentView]
        window.titlebarAppearsTransparent = true
        window.isReleasedWhenClosed = false
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
}