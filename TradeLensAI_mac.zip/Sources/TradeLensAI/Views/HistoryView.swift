import SwiftUI

struct HistoryView: View {
    @ObservedObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @State private var selected: AnalysisResult?

    var body: some View {
        NavigationSplitView {
            List(appState.history, selection: $selected) { result in
                HistoryRow(result: result)
                    .tag(result)
            }
            .listStyle(.sidebar)
            .navigationTitle(LocalizedStringKey("history"))
            .toolbar {
                ToolbarItem(placement: .destructiveAction) {
                    Button(action: {
                        appState.history.removeAll()
                        appState.storageService.saveHistory([])
                    }) {
                        Label(LocalizedStringKey("clearAll"), systemImage: "trash")
                    }
                    .help(LocalizedStringKey("clearAll"))
                    .disabled(appState.history.isEmpty)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(LocalizedStringKey("done")) { dismiss() }
                }
            }
        } detail: {
            ZStack {
                Color(nsColor: .windowBackgroundColor).ignoresSafeArea()
                
                if let result = selected {
                    HistoryDetailView(result: result)
                        .id(result.id)
                } else {
                    VStack(spacing: 16) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 48))
                            .foregroundStyle(.tertiary)
                        Text(LocalizedStringKey("selectAnalysis"))
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .frame(minWidth: 750, minHeight: 500)
    }
}

struct HistoryRow: View {
    let result: AnalysisResult

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(result.recommendation.color)
                .frame(width: 8, height: 8)
                .shadow(color: result.recommendation.color.opacity(0.3), radius: 2, x: 0, y: 1)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(result.recommendation.rawValue)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundColor(result.recommendation.color)
                
                Text(result.timestamp.formatted(date: .abbreviated, time: .shortened))
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            if let confidence = result.confidence {
                Text("\(Int(confidence * 100))%")
                    .font(.system(size: 10, weight: .heavy))
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.secondary.opacity(0.1), in: Capsule())
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

struct HistoryDetailView: View {
    let result: AnalysisResult

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Header with Badge
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(LocalizedStringKey("analysisResult"))
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.secondary)
                            .textCase(.uppercase)
                            .tracking(1)
                        
                        Text(result.recommendation.displayText)
                            .font(.system(size: 32, weight: .black, design: .rounded))
                            .foregroundColor(result.recommendation.color)
                    }
                    
                    Spacer()
                    
                    if let confidence = result.confidence {
                        VStack(alignment: .trailing, spacing: 4) {
                            Text(LocalizedStringKey("confidence"))
                                .font(.system(size: 10, weight: .bold))
                                .foregroundStyle(.secondary)
                                .textCase(.uppercase)
                            
                            Text("\(Int(confidence * 100))%")
                                .font(.system(size: 20, weight: .heavy, design: .rounded))
                                .foregroundColor(result.recommendation.color)
                        }
                    }
                }
                .padding(.horizontal, 4)

                // Screenshot
                if let data = result.screenshotData, let image = NSImage(data: data) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(LocalizedStringKey("capturedScreen"))
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.secondary)
                            .textCase(.uppercase)
                        
                        Image(nsImage: image)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .strokeBorder(Color.secondary.opacity(0.2), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                    }
                }

                // Signals
                if let signals = result.keySignals, !signals.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(LocalizedStringKey("keySignals"))
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.secondary)
                            .textCase(.uppercase)
                            .tracking(1)
                        
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(signals, id: \.self) { signal in
                                HStack(spacing: 10) {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(result.recommendation.color)
                                        .font(.system(size: 14))
                                    Text(signal)
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .padding(12)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(result.recommendation.color.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }
                }

                // Reasoning
                VStack(alignment: .leading, spacing: 12) {
                    Text(LocalizedStringKey("fullAnalysis"))
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                        .tracking(1)
                    
                    Text(result.reasoning)
                        .font(.system(size: 15, weight: .regular))
                        .lineSpacing(6)
                        .padding(20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.secondary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(Color.secondary.opacity(0.1), lineWidth: 1)
                        )
                }

                HStack {
                    Image(systemName: "calendar")
                    Text(result.timestamp.formatted(date: .complete, time: .complete))
                }
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.tertiary)
                .padding(.top, 8)
            }
            .padding(32)
        }
    }
}
